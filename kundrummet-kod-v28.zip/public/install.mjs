const $=id=>document.getElementById(id);
const standalone=window.matchMedia('(display-mode: standalone)');
let installEvent=null,installedThisSession=false,installing=false;
const isApp=()=>standalone.matches||navigator.standalone===true;
const guides={
 desktop:{steps:['Öppna Kundrummet i Chrome eller Edge och logga in vid behov.','Välj installationsikonen i adressfältet, eller webbläsarens meny för att installera sidan som app.','Bekräfta installationen. Öppna sedan Kundrummet från datorns appmeny.'],tip:'På Mac i Safari: välj Arkiv → Lägg till i Dock. Om inget installationsval finns, använd Chrome eller Edge.'},
 ios:{steps:['Öppna Kundrummet i Safari och logga in vid behov.','Öppna Dela-menyn och välj Lägg till på hemskärmen.','Låt Öppna som webbapp vara aktiverat om valet visas. Tryck på Lägg till.'],tip:'Öppna sedan Kundrummet från den nya ikonen på hemskärmen.'},
 android:{steps:['Öppna Kundrummet i Chrome och logga in vid behov.','Öppna webbläsarens meny och välj Installera app eller Lägg till på startskärmen.','Bekräfta och öppna Kundrummet från den nya ikonen.'],tip:'Benämningen kan skilja mellan telefoner och webbläsare.'}
};
function showGuide(platform){
 const guide=guides[platform]??guides.desktop;
 $('installSteps').replaceChildren(...guide.steps.map(text=>{const li=document.createElement('li');li.textContent=text;return li;}));
 $('installTip').textContent=guide.tip;
 document.querySelectorAll('[data-platform]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.platform===platform)));
}
function syncInstallUI(){
 const installed=isApp()||installedThisSession;
 $('appInstallBar').hidden=installed;
 $('nativeInstall').hidden=!installEvent||installed;
 $('nativeInstall').disabled=installing;
 $('installGuide').hidden=installed;
 $('installTitle').textContent=installed?'Kundrummet som app.':'Ett tryck bort.';
 $('installDescription').textContent=isApp()?'Du använder Kundrummet i ett eget appfönster.':installedThisSession?'Kundrummet har installerats på den här enheten. Öppna appen från din nya ikon.':'Lägg Kundrummet på hemskärmen eller i datorns appmeny. Appen öppnas i ett eget fönster.';
 document.documentElement.classList.toggle('in-app',isApp());
}
window.addEventListener('beforeinstallprompt',event=>{event.preventDefault();installEvent=event;syncInstallUI();});
window.addEventListener('appinstalled',()=>{installedThisSession=true;installEvent=null;$('installStatus').textContent='Kundrummet är installerat. Du hittar det bland dina appar.';syncInstallUI();});
standalone.addEventListener('change',syncInstallUI);
for(const id of ['installApp','appInfo'])$(id).addEventListener('click',()=>{syncInstallUI();$('installDialog').showModal();});
$('nativeInstall').addEventListener('click',async()=>{
 if(!installEvent||installing)return;
 const prompt=installEvent;installEvent=null;installing=true;syncInstallUI();
 try{
  await prompt.prompt();const choice=await prompt.userChoice;
  $('installStatus').textContent=installedThisSession?'Kundrummet är installerat.':choice.outcome==='accepted'?'Installationen har godkänts. Följ webbläsarens steg för att slutföra.':'Installationen avbröts. Du kan fortfarande använda kundrummet här.';
 }catch{$('installStatus').textContent='Installationsrutan kunde inte öppnas. Använd stegen för din enhet nedan.';}
 finally{installing=false;syncInstallUI();}
});
document.querySelectorAll('[data-platform]').forEach(b=>b.addEventListener('click',()=>showGuide(b.dataset.platform)));
const ios=/iPhone|iPad|iPod/.test(navigator.userAgent)||(navigator.platform==='MacIntel'&&navigator.maxTouchPoints>1);
showGuide(ios?'ios':/Android/.test(navigator.userAgent)?'android':'desktop');
const syncConnection=()=>{$('connectionNote').hidden=navigator.onLine!==false;};
window.addEventListener('online',syncConnection);window.addEventListener('offline',syncConnection);syncConnection();syncInstallUI();
const navLinks=[...document.querySelectorAll('.app-nav a')];
function selectSection(id){for(const a of navLinks){if(a.hash==='#'+id)a.setAttribute('aria-current','location');else a.removeAttribute('aria-current');}}
let queued=false;
function updateNav(){queued=false;if(matchMedia('(max-width:700px)').matches)return;let selected='explore';for(const id of ['explore','profile','meeting'])if($(id).getBoundingClientRect().top<window.innerHeight*.4)selected=id;selectSection(selected);}
for(const a of navLinks)a.addEventListener('click',()=>{if(!matchMedia('(max-width:700px)').matches)selectSection(a.hash.slice(1));});
window.addEventListener('scroll',()=>{if(!queued){queued=true;requestAnimationFrame(updateNav);}},{passive:true});
window.addEventListener('hashchange',()=>{if(matchMedia('(max-width:700px)').matches)return;const id=location.hash.slice(1);if(['explore','profile','meeting'].includes(id))selectSection(id);});updateNav();
