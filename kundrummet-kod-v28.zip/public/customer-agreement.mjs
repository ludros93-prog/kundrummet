// Shared validation and price logic: browser and server use the same bounded schema.
export const AGREEMENT_TYPES={fixed:'Fastpris',monthly:'Rörligt månadspris',hourly:'Timpris',quarter:'Kvartspris',portfolio:'Portfölj',mixed:'Mixavtal',other:'Annat'};
export const SOURCE_TYPES={invoice:'Faktura',contract:'Avtal',offer:'Offert',customer:'Uppgift från kunden'};
export const PRICE_MODES={constant:'Samma pris för perioden',monthly:'Pris per månad',invoice:'Fakturerad elhandel per månad'};
export const COST_PARTS={profile:'Profil / volymvägning',balance:'Balans och avräkning',certificates:'Elcertifikat / ursprung',other:'Övriga elhandelstillägg'};
export const newCustomerAgreement=(customer='')=>({version:1,provider:'',customer,product:'',area:'unknown',type:'quarter',from:'2026-01',to:'2026-12',sourceType:'invoice',sourceRef:'',sourceDate:'',mode:'monthly',composition:'total',rate:null,margin:null,other:null,monthlyFee:null,months:{},scopeConfirmed:false,notes:''});
const text=(x,max)=>typeof x==='string'&&x.length<=max;
const number=(x,min,max)=>x===null||typeof x==='number'&&Number.isFinite(x)&&x>=min&&x<=max;
export const validMonth=x=>typeof x==='string'&&/^(20[0-9]{2})-(0[1-9]|1[0-2])$/.test(x);
export const validDate=x=>typeof x==='string'&&/^20\d{2}-\d{2}-\d{2}$/.test(x)&&!Number.isNaN(Date.parse(x))&&new Date(x).toISOString().slice(0,10)===x;
export function agreementMonths(a){
 if(!validMonth(a.from)||!validMonth(a.to)||a.from>a.to)return [];
 const out=[];let [y,m]=a.from.split('-').map(Number);
 for(let i=0;i<60;i++){const key=`${y}-${String(m).padStart(2,'0')}`;if(key>a.to)break;out.push(key);if(++m===13){m=1;y++;}}
 return out.at(-1)===a.to?out:[];
}
export function validCustomerAgreement(a){
 return !!a&&a.version===1&&text(a.provider,100)&&text(a.customer,120)&&text(a.product,120)&&text(a.sourceRef,240)&&text(a.notes,2000)&&['SE1','SE2','SE3','SE4','unknown'].includes(a.area)&&Object.hasOwn(AGREEMENT_TYPES,a.type)&&Object.hasOwn(SOURCE_TYPES,a.sourceType)&&Object.hasOwn(PRICE_MODES,a.mode)&&['total','components'].includes(a.composition)&&typeof a.scopeConfirmed==='boolean'&&validMonth(a.from)&&validMonth(a.to)&&agreementMonths(a).length>0&&(a.sourceDate===''||validDate(a.sourceDate))&&number(a.rate,-500,2000)&&number(a.margin,-500,1000)&&number(a.other,-500,1000)&&number(a.monthlyFee,-100000,100000)&&a.months&&typeof a.months==='object'&&!Array.isArray(a.months)&&Object.keys(a.months).length<=60&&Object.entries(a.months).every(([k,v])=>validMonth(k)&&v&&number(v.rate,-500,2000)&&number(v.amount,-1000000000,1000000000)&&number(v.kwh,0,100000000));
}
export function agreementErrors(a,{forComparison=false}={}){
 if(!validCustomerAgreement(a))return ['Kontrollera datum och priser. Perioden får vara högst fem år.'];
 const errors=[];
 if(!a.provider.trim())errors.push('Ange leverantör.');if(!a.customer.trim())errors.push('Ange kund.');
 if(!a.sourceRef.trim())errors.push('Ange källa, till exempel fakturanummer eller offertnamn.');
 if(!validDate(a.sourceDate))errors.push('Ange datum på underlaget.');
 if(a.mode==='invoice'&&a.sourceType!=='invoice')errors.push('Fakturerade belopp behöver ha faktura som källa.');
 if(forComparison){
  if(a.area==='unknown')errors.push('Bekräfta kundens elområde.');
  if(!a.scopeConfirmed)errors.push('Bekräfta att priset omfattar all elhandel men inte moms, elnät eller energiskatt.');
  if(a.mode!=='invoice'){
   if(a.monthlyFee===null)errors.push('Ange månadsavgiften. Skriv 0 bara om avgift saknas.');
   if(a.composition==='components'&&(a.margin===null||a.other===null))errors.push('Fyll i påslag och övriga elhandelstillägg. Okända kostnader får inte anges som 0.');
   if(a.mode==='constant'&&a.rate===null)errors.push('Ange priset för perioden.');
  }
 }
 return errors;
}
export function customerMonth(a,key,kwh,{estimated=false}={}){
 if(key<a.from||key>a.to)return {available:false,reason:'Utanför kundavtalets prisperiod'};
 if(kwh===null)return {available:false,reason:'Förbrukning saknas'};
 const m=a.months[key];
 if(a.mode==='invoice'){
  if(m?.amount===null||m?.amount===undefined||m?.kwh===null||m?.kwh===undefined)return {available:false,reason:'Fakturabelopp eller fakturerad förbrukning saknas'};
  if(estimated||Math.abs(m.kwh-kwh)>.01)return {available:false,reason:'Förbrukningen måste stämma med fakturan'};
  return {available:true,cost:m.amount,rate:kwh?m.amount/kwh*100:0,monthlyFee:null};
 }
 const price=a.mode==='constant'?a.rate:m?.rate;
 if(price===null||price===undefined)return {available:false,reason:'Kundens månadspris saknas'};
 if(a.monthlyFee===null||a.composition==='components'&&(a.margin===null||a.other===null))return {available:false,reason:'Avgift eller tillägg saknas'};
 const energy=price+(a.composition==='components'?a.margin+a.other:0),cost=kwh*energy/100+a.monthlyFee;
 return {available:true,cost,rate:kwh?cost/kwh*100:energy,monthlyFee:a.monthlyFee};
}
export const customerReferenceLabel=s=>s.comparisonMode==='customer'&&s.customerAgreement?`${s.customerAgreement.provider} · ${AGREEMENT_TYPES[s.customerAgreement.type]}`:'Kvartspris';
export function customerBasis(s){
 const a=s.customerAgreement;if(s.comparisonMode!=='customer'||!a)return '';
 return `${SOURCE_TYPES[a.sourceType]}: ${a.sourceRef} (${a.sourceDate}). ${a.provider}, ${a.customer}, ${a.area}, ${a.from}–${a.to}. ${a.mode==='invoice'?'Kundens fakturerade elhandel är inmatad av säljaren och matchas mot fakturans förbrukning.':'Kundens inmatade priser tillämpas på jämförelsens förbrukning.'} Det föreslagna avtalet är en beräkning, inte kundens faktiska utfall. Samma månader används på båda sidor. Endast elhandel exklusive moms, elnät och energiskatt.`;
}
