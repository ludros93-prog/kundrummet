import {profileSourceLabel} from './model.mjs';
const $=id=>document.getElementById(id),mobile=matchMedia('(max-width:700px)');
const number=(n,d=2)=>n===null?'—':new Intl.NumberFormat('sv-SE',{maximumFractionDigits:d,minimumFractionDigits:d}).format(n);
const put=(id,text)=>$(id).textContent=text;
let page='home',comparison='year',controlsAnchor,monthsAnchor,businessAnchor;
const pages=['home','explore','profile','meeting'];
function showPage(next,{history=true,focus=false}={}){
 if(!pages.includes(next))next='home';page=next;
 document.body.dataset.mobilePage=page;
 if(!mobile.matches)return;
 document.querySelectorAll('.app-nav a').forEach(a=>{if(a.dataset.mobileTarget===page)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');});
 if(history&&location.hash!=='#'+page)window.history.pushState(null,'','#'+page);
 window.scrollTo({top:0,behavior:'instant'});
 if(page==='explore'&&comparison==='months')syncMobileMonth(Number($('monthButtons').querySelector('[aria-pressed=true]')?.dataset.monthIndex));
 if(focus){const heading=$(page).querySelector('h1,h2');if(heading){heading.tabIndex=-1;heading.focus({preventScroll:true});}}
}
function showComparison(view){comparison=view;document.body.dataset.mobileComparison=view;document.querySelectorAll('[data-comparison-view]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.comparisonView===view)));if(view==='months')syncMobileMonth(Number($('monthButtons').querySelector('[aria-pressed=true]')?.dataset.monthIndex));}
function openControls(){if(!mobile.matches)return;$('mobileControlsDialog').showModal();}
function onBreakpoint(){
 if(mobile.matches){$('mobileBusinessSlot').append($('businessImpact'));$('mobileControlsSlot').append($('scenarioControls'));$('monthFocus').before($('monthButtons'));showPage(pages.includes(location.hash.slice(1))?location.hash.slice(1):page,{history:false});}
 else{businessAnchor.after($('businessImpact'));if($('mobileControlsDialog').open)$('mobileControlsDialog').close();controlsAnchor.after($('scenarioControls'));monthsAnchor.after($('monthButtons'));document.querySelectorAll('.app-nav a').forEach(a=>a.removeAttribute('aria-current'));}
}
export function initMobile(){
 businessAnchor=document.createComment('Desktop business impact position');$('businessImpact').before(businessAnchor);
 controlsAnchor=document.createComment('Desktop controls position');$('scenarioControls').before(controlsAnchor);
 monthsAnchor=document.createComment('Desktop month selector position');$('monthButtons').before(monthsAnchor);
 document.querySelectorAll('[data-mobile-target]').forEach(el=>el.addEventListener('click',e=>{if(!mobile.matches)return;e.preventDefault();showPage(el.dataset.mobileTarget,{focus:true});}));
 document.querySelectorAll('[data-comparison-view]').forEach(el=>el.addEventListener('click',()=>showComparison(el.dataset.comparisonView)));
 $('mobileCustomer').addEventListener('click',()=>$('editCustomer').click());
 $('mobileInfo').addEventListener('click',()=>$('appInfo').click());
 $('mobileShare').addEventListener('click',()=>$('shareTop').click());
 $('mobileBalance').addEventListener('click',openControls);$('mobileAdjust').addEventListener('click',openControls);
 $('mobileApplyControls').addEventListener('click',()=>{$('mobileControlsDialog').close();showComparison('year');showPage('explore',{focus:true});});
 document.querySelector('.controls-link').addEventListener('click',e=>{if(mobile.matches){e.preventDefault();openControls();}});
 const route=()=>{if(!mobile.matches)return;const hash=location.hash.slice(1);if(hash==='scenarioControls')openControls();else if(hash==='comparisonSummary'){showComparison('year');showPage('explore',{history:false});}else showPage(pages.includes(hash)?hash:'home',{history:false});};
 window.addEventListener('load',()=>{if(mobile.matches)requestAnimationFrame(()=>showPage(page,{history:false}));},{once:true});
 window.addEventListener('popstate',route);window.addEventListener('hashchange',route);mobile.addEventListener('change',onBreakpoint);onBreakpoint();
}
export function syncMobileMonth(selected){
 if(!mobile.matches)return;
 const scroller=$('monthButtons'),button=scroller.querySelector(`[data-month-index="${selected}"]`);
 if(button)scroller.scrollLeft=button.offsetLeft-scroller.offsetLeft-scroller.clientWidth/2+button.offsetWidth/2;
}
export function renderMobile(r,s){
 const kind=!r.volume?'empty':Math.abs(r.difference)<1e-8?'equal':r.difference>0?'saving':'extra';
 put('mobileCustomerName',s.customer);put('mobileCoverage',`${r.count} av 12 månader`);
 $('mobileSavings').dataset.kind=kind;
 put('mobileSavingsTitle',{empty:'Lägg in er förbrukning',equal:'Samma beräknade kostnad',saving:'Beräknad besparing',extra:'Beräknad merkostnad'}[kind]);
 put('mobileSavingsAmount',r.volume?number(Math.abs(r.difference)): '—');
 put('mobileSavingsRate',r.volume?`${number(Math.abs(r.differenceRate))} öre/kWh ${kind==='equal'?'i skillnad':kind==='extra'?'högre':'lägre'} än rörligt`:'För att se er jämförelse');
 put('mobileSavingsBasis',`Portfölj · ${s.hedge} % säkrat · ${s.period}`);
 put('mobileFloatingCost',number(r.variable)+' kr');put('mobilePortfolioCost',number(r.portfolio)+' kr');
 put('mobileFloatingRate',number(r.variableRate)+' öre/kWh');put('mobilePortfolioRate',number(r.portfolioRate)+' öre/kWh');
 const max=Math.max(r.variable,r.portfolio,1);
 $('mobileFloatingBar').style.width=Math.max(0,r.variable)/max*100+'%';$('mobilePortfolioBar').style.width=Math.max(0,r.portfolio)/max*100+'%';
 document.querySelectorAll('.mobile-cost-track').forEach(el=>el.hidden=r.variable<0||r.portfolio<0||!r.volume);
 put('mobileVolume',number(r.volume/1000,r.volume%1000?1:0)+' MWh');
 put('mobileProfileType',s.sources[s.period]==='estimated'?'Uppskattad profil':$('seasonLabel').textContent);
 put('mobileHedge',s.hedge+' % av volymen säkrad');put('mobileFloatingShare',(100-s.hedge)+' % osäkrad volym. Andra kostnader tillkommer.');
 const estimate=s.sources[s.period]==='estimated';
 put('mobileBasis',`${r.count<12?r.count+' av 12 månader ingår. ':''}${estimate?'Uppskattad förbrukningsprofil. ':''}Beräknat från underlaget. Exkl. moms, elnät och energiskatt.`);
 $('mobileBasis').title=profileSourceLabel(s);
 put('mobileLiveResult',r.volume?`${number(Math.abs(r.difference))} kr ${kind==='extra'?'mer':kind==='equal'?'i skillnad':'mindre'} än rörligt · ${s.period}`:'Lägg in förbrukning för att jämföra.');
}
