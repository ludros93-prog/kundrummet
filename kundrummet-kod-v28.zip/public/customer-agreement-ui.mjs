import {AGREEMENT_TYPES,SOURCE_TYPES,PRICE_MODES,newCustomerAgreement,agreementMonths,agreementErrors} from './customer-agreement.mjs';
const esc=x=>String(x??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const opts=(values,current)=>Object.entries(values).map(([key,label])=>`<option value="${key}" ${key===current?'selected':''}>${esc(label)}</option>`).join('');
const number=(id,label,value,min=-500,max=2000)=>`<label>${label}<input id="${id}" data-ca="${id.slice(3)}" type="number" min="${min}" max="${max}" step="any" inputmode="decimal" value="${value??''}" placeholder="Behöver kontrolleras"></label>`;
export function bindCustomerAgreement({root,getState,onChange,onLoadCustomer}){
 let pending=null,saving=false,bankRecords=[],nextOffset=null,queryVersion=0;
 const $=id=>root.querySelector('#'+id),state=()=>getState(),agreement=()=>state().customerAgreement;
 function ensure(){const s=state();s.comparisonMode??='reference';s.customerAgreement??=newCustomerAgreement(s.customer);s.selectedMonthlyFee??=null;s.comparisonArea??='unknown';s.comparisonScopeChecked??=false;}
 function status(message,bad=false){$('ca-status').textContent=message;$('ca-status').className=bad?'error':'muted';}
 function render(){
  const openPanels=new Set([...root.querySelectorAll("details[id][open]")].map(d=>d.id));
  ensure();const s=state(),a=agreement();
  root.innerHTML=`<div class="ca-heading"><div><p class="eyebrow">JÄMFÖRELSEGRUND</p><h2>Vad betalar kunden i dag?</h2></div><button type="button" id="ca-bankOpen" class="secondary">Öppna prisbanken</button></div>
  <div class="segments ca-modes" role="group" aria-label="Välj jämförelsegrund"><button type="button" data-comparison="reference" aria-pressed="${s.comparisonMode!=='customer'}">Kvartsprisreferens</button><button type="button" data-comparison="customer" aria-pressed="${s.comparisonMode==='customer'}">Kundens avtal</button></div>
  <p class="muted">Jämför med kundens priser eller använd kvartsprisreferensen.</p>
  <div id="ca-editor" ${s.comparisonMode==='customer'?'':'hidden'}>
  <div class="form-grid"><label>Leverantör<input id="ca-provider" data-ca="provider" maxlength="100" list="ca-providers" value="${esc(a.provider)}" placeholder="Till exempel Eneas eller Fortum"></label><label>Avtalsform<select id="ca-type" data-ca="type">${opts(AGREEMENT_TYPES,a.type)}</select></label></div>
  <datalist id="ca-providers">${['Eneas','Fortum','E.ON','Vattenfall','Bixia','Göta Energi','Kraftringen'].map(x=>`<option value="${x}"></option>`).join('')}</datalist>
  <div class="ca-prices"><h3>Kundens pris</h3><label>Så vill jag ange priset<select id="ca-mode" data-ca="mode">${opts(PRICE_MODES,a.mode)}</select></label><p class="muted">Ange elhandel exklusive moms, elnät och energiskatt.</p>
  ${a.mode!=='invoice'?`${a.mode==='constant'?number('ca-rate',a.composition==='total'?'Pris inklusive tillägg, öre/kWh':'Energipris, öre/kWh',a.rate):''}
  <details id="ca-costDetails" class="ca-disclosure" ${a.composition==='components'?'open':''}><summary>Påslag och övriga tillägg <small>${a.composition==='components'?'Anges separat':'Ingår i priset'}</small></summary><label>Vad omfattar priset?<select id="ca-composition" data-ca="composition">${opts({total:'Hela elhandelspriset, inklusive tillägg',components:'Energipris + separata tillägg'},a.composition)}</select></label>${a.composition==='components'?`<div class="form-grid">${number('ca-margin','Avtalspåslag, öre/kWh',a.margin,-500,1000)}${number('ca-other','Övriga tillägg, öre/kWh',a.other,-500,1000)}</div>`:''}<p class="muted">Ta bara med tillägg som inte redan ingår i priset. Okända kostnader ska vara tomma.</p></details>
  ${number('ca-monthlyFee','Månadsavgift, kr',a.monthlyFee,-100000,100000)}<p class="muted">Skriv 0 om avgift saknas. Tomt betyder okänt.</p>`:'<p class="notice">Ange fakturans elhandelsbelopp och kWh för hela månaden. Månadsavgiften ska ingå. Ta bort moms, elnät och energiskatt.</p>'}
  <details id="ca-monthDetails" class="ca-disclosure" ${a.mode==='constant'?'hidden':''}><summary>${a.mode==='invoice'?'Fyll i fakturabelopp':'Fyll i månadspriser'} <small id="ca-monthCount"></small></summary><p class="muted">${a.mode==='invoice'?'Använd förbrukningen från samma faktura.':'För tim- och kvartspris: använd kundens förbrukningsvägda månadspris från fakturan.'} Saknade månader lämnas tomma.</p><div id="ca-months"></div>${a.mode==='invoice'?'<button type="button" id="ca-applyVolumes" class="secondary">Använd fakturornas förbrukning i mötet</button>':''}</details>
  </div>
  <details id="ca-sourceDetails" class="ca-disclosure"><summary>Period och underlag <small id="ca-sourceSummary">${esc(a.from)} – ${esc(a.to)}${a.sourceRef?' · Källa angiven':' · Ange källa'}</small></summary><div class="form-grid"><label>Uppgiften gäller kunden<input id="ca-customer" data-ca="customer" maxlength="120" value="${esc(a.customer)}"></label><label>Produkt / avtalsnamn <span class="optional">Valfritt</span><input id="ca-product" data-ca="product" maxlength="120" value="${esc(a.product)}"></label><label>Elområde<select id="ca-area" data-ca="area">${opts({unknown:'Behöver kontrolleras',SE1:'SE1',SE2:'SE2',SE3:'SE3',SE4:'SE4'},a.area)}</select></label><label>Typ av underlag<select id="ca-sourceType" data-ca="sourceType">${opts(SOURCE_TYPES,a.sourceType)}</select></label><label>Prisuppgiften gäller från<input id="ca-from" data-ca="from" type="month" min="2000-01" max="2099-12" value="${esc(a.from)}"></label><label>Till och med<input id="ca-to" data-ca="to" type="month" min="2000-01" max="2099-12" value="${esc(a.to)}"></label><label>Källa / dokumentreferens<input id="ca-sourceRef" data-ca="sourceRef" maxlength="240" value="${esc(a.sourceRef)}" placeholder="Till exempel faktura 1234 eller offert 30 oktober"></label><label>Datum på underlaget<input id="ca-sourceDate" data-ca="sourceDate" type="date" min="2000-01-01" max="2099-12-31" value="${esc(a.sourceDate)}"></label></div><label>Kommentar <span class="optional">Valfritt</span><textarea id="ca-notes" data-ca="notes" maxlength="2000" rows="2" placeholder="Till exempel rabattens giltighet.">${esc(a.notes)}</textarea></label></details>
  <label class="ca-check"><input id="ca-scopeConfirmed" data-ca="scopeConfirmed" type="checkbox" ${a.scopeConfirmed?'checked':''}><span>Jag har kontrollerat att uppgifterna omfattar all elhandel och att moms, elnät och energiskatt är borttagna.</span></label>
  <div class="ca-save"><button type="button" id="ca-save" class="secondary" ${saving?'disabled':''}>${s.customerAgreementRecord?'Spara som ny version':'Spara i teamets prisbank'}</button><p class="muted">Sparas för ${esc(a.customer||s.customer)} och blir sökbart för teamet.</p></div><p id="ca-status" class="muted" role="status">${s.customerAgreementRecord?'Inläst från prisbanken. Ändringar behöver sparas som en ny version.':'Ditt utkast sparas automatiskt på den här enheten.'}</p>
  <details id="ca-compareDetails" class="ca-compare-settings ca-disclosure"><summary>Kontrollera jämförelsen <small>Elområde och avgifter</small></summary><div class="form-grid"><label>Elområde i förslagets prisunderlag<select id="ca-comparisonArea">${opts({unknown:'Behöver kontrolleras',SE1:'SE1',SE2:'SE2',SE3:'SE3',SE4:'SE4'},s.comparisonArea)}</select></label>${number('ca-selectedMonthlyFee','Förslagets fasta avgift, kr/månad',s.selectedMonthlyFee,0,100000)}</div><p class="muted">Områdesvalet byter inte historiska priser. Kontrollera området i det prisunderlag ni använder. Förslagets fasta avgift läggs ovanpå priset per kWh; ange 0 om den redan ingår eller saknas.</p><label class="ca-check"><input id="ca-comparisonScopeChecked" type="checkbox" ${s.comparisonScopeChecked?'checked':''}><span>Jag har kontrollerat elområde, påslag, fasta avgifter och att båda alternativen avser samma kostnader och period.</span></label><p class="muted">Förslaget använder fortfarande kalkylens historik eller manuella offertpris. Jämförelsen blir inte ett verifierat faktiskt utfall för båda avtalen.</p></details></div>
  <dialog id="ca-bank" aria-labelledby="ca-bankTitle"><div class="ca-heading"><div><p class="eyebrow">TEAMETS UNDERLAG</p><h2 id="ca-bankTitle">Prisbanken</h2></div><button id="ca-bankClose" class="secondary" type="button">Stäng</button></div><p class="muted">Kundspecifika priser, inmatade av teamet. Kontrollera källa och giltighetsperiod före användning.</p><div class="ca-bank-search"><label>Sök leverantör eller kund<input id="ca-search" maxlength="120" placeholder="Eneas, Fortum eller kundnamn"></label><label>År<input id="ca-year" type="number" min="2000" max="2099" placeholder="Alla"></label><button type="button" id="ca-searchButton" class="primary">Sök</button></div><p id="ca-bankStatus" role="status"></p><div id="ca-records"></div><button type="button" id="ca-more" class="secondary" hidden>Visa fler</button></dialog>`;
  for(const id of openPanels){const panel=$(id);if(panel)panel.open=true;}
  renderMonths();updateMonthCount();
 }
 function renderMonths(){const a=agreement(),months=agreementMonths(a);$('ca-months').innerHTML=a.mode==='constant'?'':`<div class="ca-month-grid">${months.map(key=>{const m=a.months[key]||{},invoice=a.mode==='invoice';return `<div class="ca-month-row"><strong>${key}</strong>${invoice?`<label>Elhandel, kr<input data-ca-month="${key}" data-part="amount" type="number" inputmode="decimal" step="any" min="-1000000000" max="1000000000" value="${m.amount??''}" placeholder="Saknas"></label><label>Fakturerad kWh<input data-ca-month="${key}" data-part="kwh" type="number" inputmode="decimal" step="any" min="0" max="100000000" value="${m.kwh??''}" placeholder="Saknas"></label>`:`<label>${a.composition==='total'?'Hela elhandelspriset':'Energipris'}, öre/kWh<input data-ca-month="${key}" data-part="rate" type="number" inputmode="decimal" step="any" min="-500" max="2000" value="${m.rate??''}" placeholder="Saknas"></label>`}</div>`;}).join('')}</div>${months.length?'':'<p class="error">Ange en giltig period på högst fem år.</p>'}`;}
 function updateMonthCount(){const a=agreement(),months=agreementMonths(a),count=months.filter(k=>a.mode==='invoice'?a.months[k]?.amount!=null&&a.months[k]?.kwh!=null:a.months[k]?.rate!=null).length;const el=$('ca-monthCount');if(el)el.textContent=`${count} av ${months.length} månader inlagda`;}
 function revealRequired(){
  const a=agreement(),s=state();
  if(!a.sourceRef.trim()||!a.sourceDate||!agreementMonths(a).length||a.area==='unknown'||a.customer.trim().toLocaleLowerCase('sv')!==s.customer.trim().toLocaleLowerCase('sv'))$('ca-sourceDetails').open=true;
  if(a.mode!=='constant'&&!agreementMonths(a).some(k=>a.mode==='invoice'?a.months[k]?.amount!=null&&a.months[k]?.kwh!=null:a.months[k]?.rate!=null))$('ca-monthDetails').open=true;
  if(s.selectedMonthlyFee===null||s.comparisonArea==='unknown'||s.comparisonArea!==a.area||!s.comparisonScopeChecked)$('ca-compareDetails').open=true;
 }
 function changed(){onChange();const a=agreement(),summary=$('ca-sourceSummary');if(summary)summary.textContent=`${a.from} – ${a.to}${a.sourceRef?' · Källa angiven':' · Ange källa'}`;const el=$('ca-status');if(el)el.textContent='Ändrat i formuläret. Spara prisuppgiften när den är klar.';}
 root.addEventListener('input',e=>{
  const t=e.target,a=agreement(),s=state();
  if(t.dataset.caMonth){a.months[t.dataset.caMonth]??={rate:null,amount:null,kwh:null};a.months[t.dataset.caMonth][t.dataset.part]=t.value!==''&&t.validity.valid?Number(t.value):null;updateMonthCount();changed();return;}
  if(t.id==='ca-selectedMonthlyFee'){s.selectedMonthlyFee=t.value!==''&&t.validity.valid?Number(t.value):null;changed();return;}
  if(t.id==='ca-comparisonScopeChecked'){s.comparisonScopeChecked=t.checked;changed();return;}
  if(t.dataset.ca){const key=t.dataset.ca;a[key]=t.type==='checkbox'?t.checked:t.type==='number'?t.value!==''&&t.validity.valid?Number(t.value):null:t.value;changed();}
 });
 root.addEventListener('change',e=>{
  const t=e.target,a=agreement();if(t.id==='ca-comparisonArea'){state().comparisonArea=t.value;changed();}
  if(t.dataset.ca&&['mode','composition','from','to'].includes(t.dataset.ca)){if(t.dataset.ca==='mode'&&a.mode==='invoice')a.sourceType='invoice';render();}
 });
 root.addEventListener('click',async e=>{
  const t=e.target.closest('button');if(!t)return;
  if(t.dataset.comparison){state().comparisonMode=t.dataset.comparison;if(!agreement().customer)agreement().customer=state().customer;changed();render();return;}
  if(t.id==='ca-bankOpen'){$('ca-bank').showModal();await search();}
  if(t.id==='ca-bankClose'){$('ca-bank').close();$('ca-bankOpen').focus();}
  if(t.id==='ca-searchButton')await search();
  if(t.id==='ca-more')await search(nextOffset);
  if(t.id==='ca-applyVolumes'){
   const a=agreement(),entries=Object.entries(a.months).filter(([key,m])=>key>=a.from&&key<=a.to&&['2025','2026'].includes(key.slice(0,4))&&m.kwh!==null);
   if(!entries.length){status('Lägg först in fakturerad förbrukning för 2025 eller 2026.',true);return;}
   if(!confirm('Ersätta mötets förbrukningsprofiler med dessa fakturor? Månader utan fakturerad kWh lämnas tomma.'))return;
   const s=state();s.consumptionMode='separate';s.profiles={'2025':Array(12).fill(null),'2026':Array(12).fill(null)};s.estimates={};s.sources={'2025':'own','2026':'own'};for(const [key,m]of entries)s.profiles[key.slice(0,4)][Number(key.slice(5))-1]=m.kwh;
   changed();onLoadCustomer(false);status('Fakturornas förbrukning används nu. Saknade månader är tomma.');
  }
  if(t.id==='ca-save')await saveRecord();
  if(t.dataset.record){
   const record=bankRecords.find(x=>x.id===t.dataset.record);if(!record)return;
   const different=record.agreement.customer.trim().toLocaleLowerCase('sv')!==state().customer.trim().toLocaleLowerCase('sv');
   if(!confirm(different?`Öppna prisuppgiften för ${record.agreement.customer}? Ett nytt möte startas för kunden. Spara nuvarande mötesunderlag först.`:'Läsa in den sparade prisuppgiften? Osparade ändringar i avtalsformuläret ersätts.'))return;
   $('ca-bank').close();if(different)onLoadCustomer(record.agreement.customer);const s=state();s.customerAgreement=structuredClone(record.agreement);s.customerAgreementRecord={id:record.id,createdAt:record.createdAt,createdName:record.createdName};s.comparisonMode='customer';onChange();render();
  }
 });
 async function saveRecord(){
  if(saving)return;const a=structuredClone(agreement()),errors=agreementErrors(a);
  if(errors.length){revealRequired();status(errors[0],true);return;}
  const signature=JSON.stringify(a);if(!pending||pending.signature!==signature)pending={id:crypto.randomUUID(),agreement:a,supersedes:state().customerAgreementRecord?.id??null,signature};
  const body={id:pending.id,agreement:pending.agreement,supersedes:pending.supersedes};saving=true;$('ca-save').disabled=true;status('Sparar i teamets prisbank …');
  try{const res=await fetch('/api/price-records',{method:'POST',signal:AbortSignal.timeout(25000),headers:{'Content-Type':'application/json','X-Requested-With':'Kundrummet'},body:JSON.stringify(body)}),data=await res.json().catch(()=>({error:'Prisbanken svarar inte just nu. Försök igen.'}));if(!res.ok||!data.record)throw Error(data.error||'Kunde inte spara prisuppgiften.');
   if(JSON.stringify(agreement())===signature){state().customerAgreementRecord={id:data.record.id,createdAt:data.record.createdAt,createdName:data.record.createdName};onChange();pending=null;status('Sparat i teamets prisbank. '+data.record.createdName+' · '+new Date(data.record.createdAt).toLocaleDateString('sv-SE'));$('ca-save').textContent='Spara som ny version';}
   else status('Versionen sparades. Dina senaste ändringar är ännu inte sparade i prisbanken.');
  }catch(error){status(error.name==='TimeoutError'?'Prisbanken svarade inte i tid. Formuläret finns kvar; försök igen.':error.message||'Kunde inte spara. Formuläret finns kvar; försök igen.',true);}finally{saving=false;$('ca-save').disabled=false;}
 }
 async function search(offset=0){
  const seq=++queryVersion;$('ca-bankStatus').textContent='Hämtar prisuppgifter …';$('ca-more').hidden=true;
  try{const query=new URLSearchParams({q:$('ca-search').value,year:$('ca-year').value,offset:String(offset||0)}),res=await fetch('/api/price-records?'+query,{cache:'no-store',signal:AbortSignal.timeout(25000)}),data=await res.json().catch(()=>({error:'Prisbanken svarar inte just nu. Försök igen.'}));if(!res.ok||!Array.isArray(data.records))throw Error(data.error||'Prisbanken kunde inte läsas.');if(seq!==queryVersion)return;
   bankRecords=offset?[...bankRecords,...data.records]:data.records;nextOffset=data.nextOffset;
   $('ca-bankStatus').textContent=bankRecords.length?`${bankRecords.length} prisuppgifter visas.`:'Inga prisuppgifter hittades. Spara en uppgift från avtalsformuläret.';
   $('ca-records').innerHTML=bankRecords.map(r=>{const a=r.agreement,errors=agreementErrors(a,{forComparison:true});return `<article class="ca-record"><div><p class="eyebrow">${esc(a.from)} – ${esc(a.to)} · ${esc(a.area)}</p><h3>${esc(a.provider)} · ${esc(a.customer)}</h3><p>${esc(AGREEMENT_TYPES[a.type])}${a.product?' · '+esc(a.product):''}</p><p class="muted">${esc(SOURCE_TYPES[a.sourceType])}: ${esc(a.sourceRef)} · ${esc(a.sourceDate)}<br>Registrerad av ${esc(r.createdName)} · ${new Date(r.createdAt).toLocaleDateString('sv-SE')}${r.supersedes?' · Ny version':''}</p><span class="ca-tag">${errors.length?'Behöver kompletteras':'Inmatad kunduppgift'}</span></div><button type="button" class="secondary" data-record="${esc(r.id)}">Öppna uppgiften</button></article>`;}).join('');$('ca-more').hidden=nextOffset===null;
  }catch(error){if(seq===queryVersion){$('ca-bankStatus').textContent=error.name==='TimeoutError'?'Prisbanken svarade inte i tid. Försök igen.':error.message||'Prisbanken kunde inte läsas.';$('ca-records').innerHTML='';}}
 }
 return {render,revealRequired,validate(){ensure();if(state().comparisonMode!=='customer')return [];const s=state(),a=agreement(),errors=agreementErrors(a,{forComparison:true});if(a.customer.trim().toLocaleLowerCase('sv')!==s.customer.trim().toLocaleLowerCase('sv'))errors.push('Prisuppgiften och mötet måste gälla samma kund.');if(s.selectedMonthlyFee===null)errors.push('Ange förslagets fasta månadsavgift, även om den är 0.');if(s.comparisonArea!==a.area||s.comparisonArea==='unknown')errors.push('Bekräfta att båda prisunderlagen gäller samma elområde.');if(!s.comparisonScopeChecked)errors.push('Kontrollera jämförelsens förutsättningar.');if(a.mode!=='constant'&&!agreementMonths(a).some(k=>a.mode==='invoice'?a.months[k]?.amount!=null&&a.months[k]?.kwh!=null:a.months[k]?.rate!=null))errors.push('Fyll i pris eller fakturabelopp för minst en månad.');return errors.slice(0,1);}};
}
