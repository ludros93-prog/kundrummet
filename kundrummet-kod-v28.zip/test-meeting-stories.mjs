import assert from 'node:assert/strict';
import {STORY_CATALOG,STORY_PAIRS,STORY_SOURCE_NOTE,selectedStories,storyPickerHtml,embeddedStoryAppendix} from './public/meeting-stories.mjs';
import {meetingDocument} from './public/meeting-export.mjs';
for(const branch of Object.keys(STORY_PAIRS)){const selected=selectedStories(branch);assert.equal(selected.length,2);assert.equal(new Set(selected.map(s=>s.id)).size,2);assert(selected.every(s=>s.quote&&s.person&&s.source&&s.reason));}
assert.equal(Object.keys(STORY_CATALOG).length,5);
assert.deepEqual(selectedStories('transport').map(s=>s.id),['freja','repligen']);
assert.deepEqual(selectedStories('hotel').map(s=>s.id),['planetstaden','freja']);
const choice={business:'hotel',ids:['ica-bjarred','repligen']};assert.deepEqual(selectedStories('hotel',choice).map(s=>s.id),choice.ids);
for(const ids of [['freja','freja'],['constructor','repligen'],['ohlssons','tensor'],['grand-lundia','tensor'],['freja'],null])assert.deepEqual(selectedStories('hotel',{business:'hotel',ids}).map(s=>s.id),['planetstaden','freja']);
const picker=storyPickerHtml('transport');assert(picker.includes('FREJA'));assert(!picker.includes('Berättelseutkast'));assert.equal((picker.match(/data-story-slot=/g)||[]).length,2);
const appendix=await embeddedStoryAppendix('hotel',choice);assert.equal((appendix.match(/<blockquote>/g)||[]).length,2);assert(appendix.includes(STORY_SOURCE_NOTE));assert(!appendix.includes('/presentations/'));assert(!appendix.includes('<script'));
const html=meetingDocument({meeting:{customer:'<kund>',notes:'<script>alert(1)</script>',next:'Ring & följ upp',seller:'Ludwig',goal:'<img>',recommendation:'<b>Plan</b>',checks:'<script>',owner:'Karin',followUp:'2026-11-12'},branchLabel:'Hotell',periodLabel:'2025',resultMarkup:'<svg><title>Diagram</title></svg>',storyMarkup:appendix});assert(html.includes('&lt;kund&gt;'));assert(html.includes('&lt;script&gt;'));assert(!html.includes('<script>'));assert(html.includes('Karin'));assert(html.includes('2026-11-12'));
console.log('PASS: five source-backed quotes, relevant pairs, old draft selections migrated, safe offline export and escaping.');
