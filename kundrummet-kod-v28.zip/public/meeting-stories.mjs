export const STORY_CATALOG={
 "mats-palm": {
  "title": "Mats Palm",
  "sector": "Lantbruk",
  "person": "Mats Palm",
  "headline": "En genomtänkt strategi över tid",
  "quote": "Jag driver inte ett jordbruk för att sitta och spekulera i elpriset. Det viktiga är att ha en genomtänkt strategi över tid och slippa stressen kring när man ska binda. Det här upplägget känns betydligt mer seriöst än hur vi arbetade tidigare.",
  "summary": "En genomtänkt strategi över tid",
  "source": "Trygg Portfölj – ett stabilt alternativ till rörligt pris, avsnitt Kundreferenser, Kraftringen."
 },
 "freja": {
  "title": "FREJA",
  "sector": "Transport och logistik",
  "person": "Marina Wallin",
  "headline": "En kontakt som känner verksamheten",
  "quote": "Det är så värdefullt för oss att ha en personlig kontakt på Kraftringen – det förenklar dialogen och ger oss tillgång till hjälp från någon som känner vår verksamhet och kan guida oss.",
  "summary": "En kontakt som känner verksamheten",
  "source": "Trygg Portfölj – ett stabilt alternativ till rörligt pris, avsnitt Kundreferenser, Kraftringen."
 },
 "repligen": {
  "title": "Repligen Sweden AB",
  "sector": "Industri",
  "person": "Anders Rosberg",
  "headline": "Trygghet och marknadskunskap",
  "quote": "För oss handlar portföljavtalet om trygghet. Vi slipper gissa oss fram i elmarknaden och vet att någon som kan det här följer utvecklingen åt oss.",
  "summary": "Trygghet och marknadskunskap",
  "source": "Trygg Portfölj – ett stabilt alternativ till rörligt pris, avsnitt Kundreferenser, Kraftringen."
 },
 "ica-bjarred": {
  "title": "ICA Bjärred",
  "sector": "Dagligvaruhandel",
  "person": "Alex",
  "headline": "Kontroll och långsiktig strategi",
  "quote": "För oss handlar det inte om att vinna en enskild månad. Det handlar om kontroll, stabilitet och en långsiktig strategi kring energikostnaderna. Nu arbetar vi mycket mer strukturerat.",
  "summary": "Kontroll och långsiktig strategi",
  "source": "Trygg Portfölj – ett stabilt alternativ till rörligt pris, avsnitt Kundreferenser, Kraftringen."
 },
 "planetstaden": {
  "title": "First Hotel Planetstaden",
  "sector": "Hotell",
  "person": "Malin",
  "headline": "Bättre förutsägbarhet i verksamheten",
  "quote": "För oss är det viktigare att ha en långsiktig och genomtänkt strategi än att försöka tajma rätt månad eller vecka. Portföljupplägget har skapat en större trygghet och bättre förutsägbarhet i vår verksamhet.",
  "summary": "Bättre förutsägbarhet i verksamheten",
  "source": "Trygg Portfölj – ett stabilt alternativ till rörligt pris, avsnitt Kundreferenser, Kraftringen."
 }
};
export const STORY_PAIRS={
 "company": [
  [
   "repligen",
   "Marknadsbevakning och trygghet."
  ],
  [
   "ica-bjarred",
   "Kontroll och en långsiktig strategi."
  ]
 ],
 "brf": [
  [
   "ica-bjarred",
   "Närliggande behov: kontroll över energikostnaden."
  ],
  [
   "planetstaden",
   "Närliggande behov: förutsägbarhet i verksamheten."
  ]
 ],
 "hotel": [
  [
   "planetstaden",
   "Samma bransch: hotell och långsiktig planering."
  ],
  [
   "freja",
   "Personlig kontakt och vägledning."
  ]
 ],
 "industry": [
  [
   "repligen",
   "Samma bransch: industri och marknadsbevakning."
  ],
  [
   "ica-bjarred",
   "Kontroll och struktur kring energikostnaden."
  ]
 ],
 "farm": [
  [
   "mats-palm",
   "Samma bransch: lantbruk och inköpsstrategi."
  ],
  [
   "ica-bjarred",
   "Långsiktig kostnadsplanering."
  ]
 ],
 "shop": [
  [
   "ica-bjarred",
   "Samma bransch: dagligvaruhandel och kostnadskontroll."
  ],
  [
   "planetstaden",
   "Långsiktig planering i en serviceverksamhet."
  ]
 ],
 "transport": [
  [
   "freja",
   "Samma bransch: transport och personlig kontakt."
  ],
  [
   "repligen",
   "Marknadsbevakning och fokus på verksamheten."
  ]
 ],
 "property": [
  [
   "planetstaden",
   "Närliggande behov: förutsägbarhet i verksamheten."
  ],
  [
   "ica-bjarred",
   "Kontroll över energikostnaden."
  ]
 ],
 "other": [
  [
   "repligen",
   "Marknadsbevakning och trygghet."
  ],
  [
   "ica-bjarred",
   "Kontroll och en långsiktig strategi."
  ]
 ]
};
export const STORY_SOURCE_NOTE='Kundernas egna erfarenheter ur Kraftringens presentation Trygg Portfölj. Citaten beskriver portföljförvaltning och är inget löfte om ett visst pris eller resultat.';
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export function validStoryChoice(choice,business){return !!choice&&choice.business===business&&Array.isArray(choice.ids)&&choice.ids.length===2&&new Set(choice.ids).size===2&&choice.ids.every(id=>typeof id==='string'&&Object.hasOwn(STORY_CATALOG,id));}
export function selectedStories(business,choice){const pair=STORY_PAIRS[business]??STORY_PAIRS.other;return (validStoryChoice(choice,business)?choice.ids:pair.map(x=>x[0])).map(id=>({id,...STORY_CATALOG[id],reason:pair.find(x=>x[0]===id)?.[1]??'Vald som ett relevant exempel för vårt samtal.'}));}
export function storyPickerHtml(business,choice,{compact=false}={}){
 const stories=selectedStories(business,choice),manual=validStoryChoice(choice,business);
 return `<section class="sheet compact-stories" aria-labelledby="storiesHeading"><div class="stories-heading"><div><p class="eyebrow">ERFARENHETER AV PORTFÖLJFÖRVALTNING</p><h2 id="storiesHeading">Två kundröster att ta med</h2></div></div><div class="story-list">${stories.map(story=>`<a class="story-row" href="/presentation.html?deck=${story.id}" target="_blank" rel="noopener" aria-label="Läs kundrösten från ${story.title}"><span class="quote-mark" aria-hidden="true">”</span><span><small>${story.sector}</small><strong>${story.title}</strong><small>${story.headline}</small></span><span class="story-arrow" aria-hidden="true">↗</span></a>`).join('')}</div><p class="reference-source">Ur Kraftringens presentation Trygg Portfölj. Kundernas erfarenheter gäller portföljförvaltning.</p><details id="storyChoices"><summary>Se urvalet eller byt kundröster</summary><p class="muted">${manual?'Valda för vårt samtal.':'Förslag utifrån er bransch eller liknande behov.'}</p>${stories.map((story,i)=>`<label for="storyChoice${i}">Kundröst ${i+1}<select id="storyChoice${i}" data-story-slot="${i}">${Object.entries(STORY_CATALOG).map(([id,item])=>`<option value="${id}" ${id===story.id?'selected':''} ${id===stories[1-i].id?'disabled':''}>${item.title} · ${item.sector}</option>`).join('')}</select></label><p class="muted">${story.reason}</p>`).join('')}${manual?'<button type="button" class="text-button" data-story-auto>Återställ branschens förslag</button>':''}<p class="muted">${STORY_SOURCE_NOTE}</p></details></section>`;
}
export async function embeddedStoryAppendix(business,choice){return `<section class="export-stories"><h2>Kundernas egna ord</h2>${selectedStories(business,choice).map(story=>`<article class="export-story"><p>${esc(story.sector)}</p><h3>${esc(story.title)}</h3><blockquote>”${esc(story.quote)}”</blockquote><p>${esc(story.person)}</p><p>${esc(story.source)}</p></article>`).join('')}<p>${STORY_SOURCE_NOTE}</p></section>`;}
