import assert from 'node:assert/strict';
import {calculate,parseProfile,defaults,MONTHS,DATA,validateState,migrateLegacy,PROFILE_SHAPES,annualProfile,profileSourceLabel,hasMonthlyPrices} from './public/model.mjs';
const near=(actual,expected)=>assert.ok(Math.abs(actual-expected)<1e-7,`${actual} != ${expected}`);
const s=defaults();
// Independently calculated from the supplied worksheet using decimal arithmetic.
for(const [period,volume,portfolio,variable,fixed,at100,diff] of [
 ['2025',186000,124459.56,135489.8,188604,121888,11030.24],
 ['2026',126000,91805.82,129075.9,127764,82614.3,37270.08]
]){
 const state={...s,period},r=calculate(state);
 for(const [actual,expected] of [[r.volume,volume],[r.portfolio,portfolio],[r.variable,variable],[r.fixed,fixed],[r.difference,diff],[calculate({...state,hedge:100}).portfolio,at100]])near(actual,expected);
 near(calculate({...state,hedge:0}).difference,volume*.004);
 near(calculate({...state,consumption:150}).portfolio,portfolio*1.5);
 near(r.portfolioRate,portfolio/volume*100);
}
// One month's actual units: Jan 2025 at 80% -> 87.724 öre, 8,772.40 kr.
near(calculate(s).rows[0].portfolioRate,87.724);near(calculate(s).rows[0].portfolio,8772.4);
const partial=calculate({...s,period:'2026'});assert.equal(partial.count,9);
assert.ok(partial.rows.slice(9).every(row=>row.available===false&&!Object.hasOwn(row,'portfolio')));
// A full annual profile does not create missing 2026 prices or zero-cost Q4.
const annual={...s,period:'2026',profiles:{...s.profiles,'2026':Array(12).fill(10000)}};
assert.equal(calculate(annual).volume,90000);assert.equal(calculate(annual).count,9);
const noJan={...s,profiles:{...s.profiles,'2025':[null,...s.profiles['2025'].slice(1)]}};
near(calculate(noJan).portfolio,calculate(s).portfolio-8772.4);assert.equal(calculate(noJan).count,11);
const zero={...s,profiles:{...s.profiles,'2025':Array(12).fill(0)}};assert.ok(validateState(zero));assert.equal(calculate(zero).portfolioRate,null);
assert.deepEqual(parseProfile('Månad;kWh\n'+MONTHS.map((m,i)=>m+';'+s.profiles['2025'][i]).reverse().join('\n')),s.profiles['2025']);
assert.deepEqual(parseProfile('Månad;kWh\nJan;1 000,5\nFeb;0\nMar;'),[1000.5,0,...Array(10).fill(null)]);
assert.throws(()=>parseProfile('Jan;100\nJan;200'));assert.throws(()=>parseProfile('Jan;-1'));assert.throws(()=>parseProfile('Jan;100\n200'));assert.throws(()=>parseProfile('Jan;abc'));
assert.ok(validateState(s));assert.ok(!validateState({...s,hedge:101}));assert.ok(!validateState({...s,portfolioFee:-1}));assert.ok(!validateState({...s,basis:'wrong'}));
const old={customer:'Existing customer',profile:Array(12).fill(2000),scenario:'base',consumption:120,hedge:65,fixed:70,fee:4,notes:'Keep notes',next:'Follow up',date:'2026-11-02',choice:'secured'};
const migrated=migrateLegacy(old);assert.ok(validateState(migrated));assert.equal(migrated.notes,old.notes);assert.equal(migrated.hedge,65);assert.equal(migrated.choice,'portfolio');assert.equal(migrated.fixed,101.4);assert.equal(migrated.portfolioFee,2);assert.deepEqual(migrated.profiles['2025'],old.profile);assert.equal(migrated.sources['2026'],'own');
assert.ok(validateState(JSON.parse(JSON.stringify(s))));
assert.equal(DATA.periods['2025'].hedged.length,12);assert.equal(DATA.periods['2026'].hedged.filter(x=>x!==null).length,9);
// Savings use the same consumed volume as both prices; do not average monthly savings.
near(calculate(s).differenceRate,5.930236559139785);
near(calculate({...s,period:'2026'}).differenceRate,29.57942857142857);
near(calculate(s).rows[0].differenceRate,-5.504);
near(calculate(s).rows[0].difference,-550.4);
near(calculate({...s,consumption:150}).differenceRate,calculate(s).differenceRate);
near(calculate({...s,consumption:150}).difference,calculate(s).difference*1.5);
near(calculate(s).rows.reduce((sum,row)=>sum+row.differenceRate*row.volume,0)/calculate(s).volume,calculate(s).differenceRate);
assert.equal(calculate(zero).differenceRate,null);
const equal=calculate({...s,hedge:0,portfolioFee:s.variableFee});near(equal.differenceRate,0);near(equal.difference,0);
const higher=calculate({...s,portfolioFee:20});assert.ok(higher.differenceRate<0&&higher.difference<0);
assert.ok(partial.rows.slice(9).every(row=>!Object.hasOwn(row,'differenceRate')));
const {priceChart,differenceChart}=await import('./public/charts.mjs');
for(const result of [calculate(s),partial,calculate(zero),higher,equal])for(const unit of ['ore','kr']){
 for(const chart of [priceChart(result,unit),differenceChart(result,unit)])assert.ok(!/NaN|Infinity/.test(chart));
}
console.log('PASS: verified worksheet totals, 0/80/100% hedging, independent monthly check, missing months, weighted prices, import, validation and legacy migration.');
console.log(JSON.stringify({2025:calculate(s),2026:calculate({...s,period:'2026'})},(k,v)=>k==='rows'?undefined:v));
// Annual estimates preserve the annual total, including fractional kWh.
const winterMonths=[0,1,2,9,10,11];
for(const shape of Object.keys(PROFILE_SHAPES))for(const annual of [.01,1,100.01,100000,186000.37,100000000]){
 const profile=annualProfile(annual,shape);
 assert.equal(profile.length,12);assert.ok(profile.every(v=>Number.isFinite(v)&&v>=0));
 near(profile.reduce((a,v)=>a+v,0),annual);
}
const winterProfile=annualProfile(100000,'winter'),summerProfile=annualProfile(100000,'summer'),evenProfile=annualProfile(120000,'even');
assert.deepEqual(winterProfile,[12000,12000,11000,8000,6000,4000,4000,5000,8000,9000,10000,11000]);
near(winterMonths.reduce((a,i)=>a+winterProfile[i],0),65000);
near(winterMonths.reduce((a,i)=>a+summerProfile[i],0),35000);
assert.ok(evenProfile.every(v=>v===10000));
for(const bad of [-1,0,.001,NaN,Infinity,100000001])assert.throws(()=>annualProfile(bad,'winter'));
assert.throws(()=>annualProfile(100000,'bad'));assert.throws(()=>annualProfile(100000,'__proto__'));
const estimate={...defaults(),period:'2026'};estimate.profiles['2026']=winterProfile;estimate.sources['2026']='estimated';estimate.estimates['2026']={annualKwh:100000,shape:'winter',adjusted:false};
assert.ok(validateState(estimate));assert.ok(validateState(JSON.parse(JSON.stringify(estimate))));
assert.match(profileSourceLabel(estimate),/Uppskattad profil: vintertung/);
const estimatedResult=calculate(estimate);assert.equal(estimatedResult.count,9);near(estimatedResult.volume,70000);
assert.ok(estimatedResult.rows.slice(9).every(r=>!r.available&&r.volume>0));
assert.deepEqual(estimate.profiles['2025'],defaults().profiles['2025']);
const forged=structuredClone(estimate);forged.profiles['2026'][0]+=100;assert.equal(validateState(forged),false);
forged.estimates['2026'].adjusted=true;assert.ok(validateState(forged));assert.match(profileSourceLabel(forged),/justerats manuellt/);
const missingMeta=structuredClone(estimate);delete missingMeta.estimates;assert.equal(validateState(missingMeta),false);
const legacyV2=defaults();delete legacyV2.estimates;assert.ok(validateState(legacyV2));
console.log('PASS: annual shape shares, exact annual totals, invalid input, estimated provenance, JSON round-trip and partial-year comparison.');
// Availability follows the data as prices are added; zero is a valid price.
const updatedPrices=structuredClone(DATA.periods['2026']);
assert.equal(MONTHS.filter((_,i)=>hasMonthlyPrices(updatedPrices,i)).length,9);
for(const key of ['hedged','spot','running','weighting'])updatedPrices[key][9]=0;
assert.equal(MONTHS.filter((_,i)=>hasMonthlyPrices(updatedPrices,i)).length,10);
updatedPrices.weighting[9]=null;assert.equal(hasMonthlyPrices(updatedPrices,9),false);
for(const key of ['hedged','spot','running','weighting'])for(let i=9;i<12;i++)updatedPrices[key][i]=0;
assert.equal(MONTHS.filter((_,i)=>hasMonthlyPrices(updatedPrices,i)).length,12);
// Visual comparisons must preserve negative/zero outcomes and missing-data gaps.
const {monthFocus,monthButtons}=await import('./public/charts.mjs');
assert.match(monthFocus(calculate(s),0),/Merkostnad med portfölj/);
assert.match(monthFocus(calculate(s),0),/550,40/);
assert.match(monthFocus(calculate(s),0),/5,50 öre\/kWh högre/);
assert.match(monthFocus(equal,0),/Samma kostnad/);
assert.match(monthFocus(calculate(zero),0),/Prisskillnad · 0 kWh/);
assert.equal((monthButtons(partial).match(/disabled/g)||[]).length,3);
const crossing={periodLabel:'2025',rows:[{index:0,available:true,variableRate:80,portfolioRate:100,fixedRate:90},{index:1,available:true,variableRate:100,portfolioRate:80,fixedRate:90}]};
assert.match(priceChart(crossing),/data-gap="extra"/);assert.match(priceChart(crossing),/data-gap="saving"/);
crossing.rows[0].available=false;assert.doesNotMatch(priceChart(crossing),/data-gap=/);
const noMonths={...partial,count:0,rows:partial.rows.map(row=>({...row,available:false}))};
assert.match(monthFocus(noMonths,null),/Lägg in förbrukning/);
assert.ok(!/NaN|Infinity/.test(priceChart(noMonths)+monthButtons(noMonths)));
console.log('PASS: chart crossings, missing months, negative/zero savings and empty comparison.');
