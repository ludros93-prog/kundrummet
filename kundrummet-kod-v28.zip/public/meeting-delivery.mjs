// Prepare first; file actions must run from a fresh, explicit user gesture.
export function bindPdfDelivery({button,status,actions,download,open,share,getMeeting,generate,platform=globalThis}){
 let readyFile=null,url=null,generation=0;
 const say=(message,error=false)=>{status.hidden=false;status.classList.toggle('error',error);status.textContent=message;};
 function invalidate(){generation++;readyFile=null;actions.hidden=true;status.hidden=true;}
 button.addEventListener('click',async()=>{
  if(button.disabled)return;
  const ticket=++generation,snapshot=structuredClone(getMeeting());readyFile=null;actions.hidden=true;
  button.disabled=true;button.textContent='Skapar PDF …';say('Sätter samman ert mötesunderlag. Vänta tills filen är klar.');
  try{
   const result=await generate(snapshot);
   if(ticket!==generation||JSON.stringify(snapshot)!==JSON.stringify(getMeeting())){say('Mötesuppgifterna ändrades. Tryck på Skapa PDF för ett aktuellt underlag.');return;}
   const file=new platform.File([result.bytes],result.filename,{type:'application/pdf'});
   const nextUrl=platform.URL.createObjectURL(file);if(url)platform.URL.revokeObjectURL(url);url=nextUrl;readyFile=file;
   download.href=url;download.download=result.filename;open.href=url;
   let canShare=false;try{canShare=typeof platform.navigator.share==='function'&&platform.navigator.canShare?.({files:[file]})===true;}catch{}
   share.hidden=!canShare;actions.hidden=false;
   say(`PDF klar: ${result.pageCount} sidor. Välj Hämta PDF eller Öppna PDF nedan. ${canShare?'På iPhone: välj Dela/spara och sedan Spara i Filer.':''}${result.replacedCharacters.length?' Vissa specialtecken har ersatts med frågetecken; kontrollera texten före delning.':''}`);
   download.focus({preventScroll:true});actions.scrollIntoView({behavior:'smooth',block:'nearest'});
  }catch(e){say('PDF:en kunde inte skapas. '+e.message+' Försök igen.',true);}
  finally{button.disabled=false;button.textContent='Skapa PDF';}
 });
 // No generation/fetch/await before calling share: preserve the user's activation.
 share.addEventListener('click',async()=>{
  if(!readyFile||share.disabled)return;
  share.disabled=true;
  try{await platform.navigator.share({files:[readyFile],title:readyFile.name});say('Delningsdialogen har stängts. PDF:en finns kvar här om du vill spara eller dela igen.');}
  catch(e){if(e.name==='AbortError')say('Delningen avbröts. PDF:en finns kvar; välj Hämta PDF eller Dela/spara igen.');else say('Mobilens delning kunde inte öppnas. Välj Öppna PDF och spara från PDF-visaren, eller öppna kundrummet i Safari.',true);}
  finally{share.disabled=false;}
 });
 download.addEventListener('click',()=>say('Nedladdningen har begärts. Om ingen fil visas: välj Öppna PDF, eller Dela/spara och Spara i Filer på iPhone.'));
 return {invalidate};
}
