import {CONTRACTS} from './meeting-model.mjs';
const fmt=(n,d=2)=>new Intl.NumberFormat('sv-SE',{minimumFractionDigits:d,maximumFractionDigits:d}).format(n);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

export function monthComparison(r,index){
 const row=r.rows[index];
 return !row?.available?null:{...row,difference:row.variable-row.selected,differenceRate:row.variableRate-row.selectedRate};
}
export function priceRanges(r){
 const rows=r.available.filter(x=>x.volume>0);
 if(!rows.length)return null;
 const bounds=key=>({low:Math.min(...rows.map(x=>x[key])),high:Math.max(...rows.map(x=>x[key]))});
 return {selected:bounds('selectedRate'),variable:bounds('variableRate')};
}
function niceStep(span){const rough=Math.max(span/4,.01),p=10**Math.floor(Math.log10(rough)),v=rough/p;return(v<=1?1:v<=2?2:v<=2.5?2.5:v<=5?5:10)*p;}
export function meetingChart(r,label,unit='ore',difference=false){
 const selected=unit==='ore'?'selectedRate':'selected',variable=unit==='ore'?'variableRate':'variable';
 const w=Math.max(700,r.rows.length*36+80),h=difference?220:280,L=64,R=25,T=30,B=44,ph=h-T-B;
 const values=r.available.flatMap(row=>difference?[row[variable]-row[selected]]:[row[selected],row[variable]]);
 const step=niceStep(Math.max(0,...values)-Math.min(0,...values)),min=Math.floor(Math.min(0,...values)/step)*step,max=Math.max(step,Math.ceil(Math.max(0,...values)/step)*step);
 const x=i=>L+i*(w-L-R)/Math.max(1,r.rows.length-1),y=v=>T+ph-(v-min)/(max-min)*ph;
 const labelUnit=unit==='ore'?'öre/kWh':'kr',prefix=difference?'monthly-difference':'monthly-price';
 let svg=`<svg viewBox="0 0 ${w} ${h}" style="min-width:${w}px" role="img" aria-labelledby="${prefix}-title ${prefix}-desc"><title id="${prefix}-title">${difference?'Besparing eller merkostnad per månad':'Utveckling månad för månad'} i ${labelUnit}</title><desc id="${prefix}-desc">${difference?'Blå positiva staplar visar lägre kostnad med valt avtal, röda negativa staplar visar högre kostnad.':`${esc(label)} i blått och ${esc(r.referenceLabel||'Kvartspris')} i streckad korallfärgad linje.`} Saknade månader lämnas tomma. Exakta värden finns i månadstabellen.</desc>`;
 for(let v=min;v<=max+step*.01;v+=step)svg+=`<line x1="${L}" x2="${w-R}" y1="${y(v)}" y2="${y(v)}" stroke="${Math.abs(v)<1e-8?'#9fb2bd':'#dfe7eb'}" stroke-dasharray="${Math.abs(v)<1e-8?'none':'3 5'}"/><text x="${L-10}" y="${y(v)+4}" text-anchor="end" fill="#526572" font-size="11">${fmt(unit==='kr'?v/1000:v,step<1?2:1)}</text>`;
 svg+=`<text x="${L}" y="15" fill="#526572" font-size="11">${unit==='kr'?'tusen kr':'öre/kWh'}</text>`;
 r.rows.forEach((row,i)=>{
  if(!row.available)svg+=`<rect x="${x(i)-16}" y="${T}" width="32" height="${ph}" fill="#f1f4f5"/><text x="${x(i)}" y="${T+ph/2}" text-anchor="middle" fill="#687f8d" font-size="14">—</text>`;
  svg+=`<text x="${x(i)}" y="${h-20}" text-anchor="middle" fill="#526572" font-size="11">${row.month}</text>`;
  if(i===0||row.year!==r.rows[i-1].year)svg+=`<text x="${x(i)}" y="${h-5}" text-anchor="middle" fill="#013c57" font-weight="600" font-size="10">${row.year}</text>`;
 });
 if(difference){
  r.rows.forEach((row,i)=>{if(!row.available)return;const d=row[variable]-row[selected],color=d>=0?'#007aa3':'#b84636';
   svg+=`<rect x="${x(i)-12}" y="${Math.min(y(d),y(0))}" width="24" height="${Math.max(1,Math.abs(y(d)-y(0)))}" rx="3" fill="${color}"><title>${row.label}: ${d>=0?'lägre':'högre'} med ${fmt(Math.abs(d))} ${labelUnit}</title></rect>`;
  });
 }else{
  for(const [key,color,dash] of [[variable,'#b84636',true],[selected,'#007aa3',false]]){
   let path='',active=false;
   r.rows.forEach((row,i)=>{if(!row.available){active=false;return;}path+=`${active?'L':'M'}${x(i)},${y(row[key])} `;active=true;});
   svg+=`<path d="${path}" stroke="${color}" stroke-width="3" ${dash?'stroke-dasharray="6 5"':''} fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;
   r.rows.forEach((row,i)=>{if(row.available)svg+=`<circle cx="${x(i)}" cy="${y(row[key])}" r="3" fill="white" stroke="${color}" stroke-width="2"><title>${row.label}: ${key===selected?esc(label):esc(r.referenceLabel||'Kvartspris')} ${fmt(row[key])} ${labelUnit}</title></circle>`;});
  }
 }
 r.rows.forEach((row,i)=>{svg+=`<rect data-chart-row="${i}" x="${x(i)-20}" y="${T}" width="40" height="${ph}" fill="transparent" style="cursor:pointer"><title>${row.label}${row.available?' · visa månadens siffror':' · underlag saknas'}</title></rect>`;});
 return svg+'</svg>';
}
export function monthFocusHtml(r,index,label){
 const row=monthComparison(r,index);
 if(!row)return `<div class="month-focus"><h3>${esc(r.rows[index]?.label??'Månad')}</h3><p>Komplett pris- eller förbrukningsunderlag saknas. Månaden ingår inte i jämförelsen.</p></div>`;
 const equal=Math.abs(row.difference)<.005;
 return `<div class="month-focus"><div class="focus-heading"><h3>${row.label}</h3><span>${fmt(row.volume)} kWh</span></div><div class="month-metrics"><div><span>${esc(label)}</span><strong>${fmt(row.selected)} kr</strong><small>${fmt(row.selectedRate)} öre/kWh</small></div><div><span>${esc(r.referenceLabel||'Kvartspris')}</span><strong>${fmt(row.variable)} kr</strong><small>${fmt(row.variableRate)} öre/kWh</small></div><div class="${row.difference>=0?'saving':'extra'}"><span>${equal?'Samma kostnad':row.difference>0?'Beräknad besparing':'Beräknad merkostnad'}</span><strong>${fmt(Math.abs(row.difference))} kr</strong><small>${fmt(Math.abs(row.differenceRate))} öre/kWh ${equal?'i prisskillnad':row.differenceRate>=0?'lägre':'högre'}${row.volume===0?' · ingen förbrukning':''}</small></div></div></div>`;
}
export function chartsHtml(r,s,unit='ore',focus=0,interactive=true,compact=false){
 const label=CONTRACTS[s.contract].label,range=priceRanges(r);
 return `<section class="sheet chart-sheet" aria-labelledby="chartHeading"><div class="chart-header"><div><p class="eyebrow">FÖLJ SKILLNADEN</p><h2 id="chartHeading">Månad för månad</h2></div>${interactive?`<div class="segments" aria-label="Diagrammets enhet"><button type="button" data-chart-unit="ore" aria-pressed="${unit==='ore'}">Öre/kWh</button><button type="button" data-chart-unit="kr" aria-pressed="${unit==='kr'}">Kronor</button></div>`:''}</div><div class="chart-legend"><span><i class="selected-line"></i>${label}</span><span><i class="variable-line"></i>${esc(r.referenceLabel||'Kvartspris')}</span></div><p class="muted">${unit==='ore'?'Priset per kWh gör det lättare att jämföra prisvariationer.':'Kostnaden i kronor visar både prisets och förbrukningens påverkan.'} Samma månader används för båda avtalen.</p><div class="chart-scroll" tabindex="0" aria-label="Prisdiagram, bläddra i sidled vid behov">${meetingChart(r,label,unit)}</div>${compact?'<details class="chart-extra"><summary>Se besparing eller merkostnad per månad</summary>':''}<h3>Besparing eller merkostnad</h3><p class="muted">Blått över noll = lägre med valt avtal. Rött under noll = högre med valt avtal.</p><div class="chart-scroll" tabindex="0" aria-label="Skillnadsdiagram, bläddra i sidled vid behov">${meetingChart(r,label,unit,true)}</div>${compact?'</details>':''}${interactive?`<p class="chart-hint">Svep diagrammen i sidled på mobilen. Tryck på en månad eller välj nedan.</p>${compact?'<details id="monthDetails"><summary>Se exakta månadssiffror</summary>':''}<label class="focus-select">Visa månad<select id="focusMonth">${r.rows.map((row,i)=>`<option value="${i}" ${i===focus?'selected':''}>${row.label}${row.available?'':' · saknar underlag'}</option>`).join('')}</select></label><div id="monthFocus" aria-live="polite">${monthFocusHtml(r,focus,label)}</div>${compact?'</details>':''}`:''}${range?`<details><summary>Hur mycket varierade månadspriset?</summary><div class="price-ranges"><p><span>${label}</span><strong>${fmt(range.selected.low)}–${fmt(range.selected.high)} öre/kWh</strong></p><p><span>${esc(r.referenceLabel||'Kvartspris')}</span><strong>${fmt(range.variable.low)}–${fmt(range.variable.high)} öre/kWh</strong></p></div><p class="muted">Lägsta och högsta månadspris bland månader med förbrukning. Det beskriver det här underlaget, inte framtida prisrisk.</p></details>`:''}</section>`;
}

const portfolioBenefits=[
 ['Tryggare planering','En plan för prissäkringen ger stöd för budgeten och minskar beroendet av en enda köpdag.'],
 ['Jämnare pris över tid','Prissäkring vid flera tillfällen kan dämpa prisrörelser. Priset kan fortfarande variera.'],
 ['Tydlig kostnadsbild','Här visar vi pris, påslag och antaganden. Gå också igenom vilka avgifter som tillkommer i avtalet.']
];
export const CONTRACT_DESCRIPTIONS={
 "individual": {
  "intro": "En egen inköpsplan utifrån er förbrukning och risknivå.",
  "benefits": [
   [
    "En egen plan",
    "Inköpsplanen utgår från er verksamhet, förbrukning och risknivå."
   ],
   [
    "Inköp över tid",
    "Prissäkringarna fördelas enligt den plan vi kommer överens om."
   ],
   [
    "Gemensam uppföljning",
    "Vi följer upp förbrukning och förändringar som påverkar planen."
   ]
  ]
 },
 "safe": {
  "intro": "Gemensamma inköp som sprids över tid för en jämnare prisbild.",
  "benefits": [
   [
    "Gemensamma inköp",
    "Ni ingår i en pool med en gemensam inköpsstrategi."
   ],
   [
    "Löpande prissäkring",
    "Inköpen sprids över tid för att dämpa beroendet av ett enskilt köptillfälle."
   ],
   [
    "Mindre egen bevakning",
    "Förvaltningen följer strategin. Ni kan fokusera på verksamheten."
   ]
  ]
 },
 "offensive": {
  "intro": "Gemensam prissäkring med aktiv förvaltning av delar av inköpen.",
  "benefits": [
   [
    "En gemensam grund",
    "En del av inköpen följer poolens löpande prissäkring."
   ],
   [
    "Aktiva beslut",
    "Delar förvaltas aktivt utifrån marknadsläget."
   ],
   [
    "Acceptera variation",
    "Aktiv förvaltning kan ge både bättre och sämre prisutfall."
   ]
  ]
 },
 "direct": {
  "intro": "Säkra vid ett tillfälle, med ett säkringspris för varje avtalsmånad.",
  "benefits": [
   [
    "Ett säkringstillfälle",
    "En överenskommen andel säkras vid ett tillfälle för avtalsperioden."
   ],
   [
    "Pris för varje månad",
    "Varje avtalsmånad får sin egen kända säkringsnivå."
   ],
   [
    "Planera för återstoden",
    "Osäkrad volym, användningsmönster och avgifter påverkar slutpriset."
   ]
  ]
 },
 "stable": {
  "intro": "Ett gemensamt säkringspris, vägt efter er månadsförbrukning.",
  "benefits": [
   [
    "En gemensam nivå",
    "Månadernas säkringspriser vägs samman efter er förbrukningsprofil."
   ],
   [
    "En grund för budget",
    "Samma säkringspris används under den överenskomna perioden."
   ],
   [
    "Följ upp förbrukningen",
    "Profil, faktisk volym och osäkrad del påverkar fortfarande fakturan."
   ]
  ]
 },
 "quarter": {
  "intro": "Följ marknaden och påverka kostnaden genom när ni använder el.",
  "benefits": [
   [
    "Följ marknadspriset",
    "Både stigande och fallande spotpriser får genomslag."
   ],
   [
    "Påverka tidpunkten",
    "Flyttbar elanvändning kan läggas på billigare kvartar."
   ],
   [
    "Planera för svängningar",
    "Budgeten behöver klara att marknadspriset varierar."
   ]
  ]
 },
 "fixed": {
  "intro": "Ett avtalat pris för den del och period som omfattas av offerten.",
  "benefits": [
   [
    "Ett avtalat pris",
    "Den fasta prisdelen gäller under perioden i offerten."
   ],
   [
    "Enklare prisbudget",
    "Förbrukningen påverkar fortfarande månadskostnaden."
   ],
   [
    "Tydliga villkor",
    "Vi går igenom volymvillkor, tillägg och avtalstid tillsammans."
   ]
  ]
 }
};
export const BRANCH_PROMPTS={
 hotel:'Hur påverkar beläggning och drift er budget för el?',industry:'Hur viktigt är ett planerat elpris när ni kalkylerar produktionen?',farm:'Hur varierar behovet mellan säsongerna?',shop:'Vilken del av butikens elanvändning går faktiskt att flytta i tid?',brf:'Hur stora kostnadsförändringar klarar föreningens budget?',transport:'När använder terminaler och laddning mest el?',property:'Hur följer ni upp energikostnaden per fastighet?',company:'Vad väger tyngst för er: planering eller att följa marknadens pris?',other:'Vad väger tyngst för er: planering eller att följa marknadens pris?'
};
export function benefitsHtml(s){
 const c=CONTRACTS[s.contract],v=CONTRACT_DESCRIPTIONS[s.contract],portfolio=c.kind==='portfolio';
 const caveat=portfolio?'Säkringarna är finansiella prisavtal, inte el som läggs i lager. De kan även göra utfallet dyrare än rörligt. Förbrukning, dygnsprofil och övriga kostnader kan fortfarande påverka fakturan.':s.contract==='quarter'?'Ni bär marknadens prisvariationer. Jämförelsen använder månadspriser och kan inte visa vinsten av att flytta användning mellan kvartar.':['stable','direct'].includes(s.contract)?'Ett konstant pris i kalkylen innebär inte att hela elräkningen är garanterat fast. Offertens omfattning måste stämma med det inmatade priset.':'Ett fast pris per kWh betyder inte en fast månadsfaktura. Förbrukning, avtalets tillägg, elnät och skatt behöver också räknas med.';
 const rows=portfolio?[
  ['När priset formas','Stegvis, genom prissäkringar före förbrukningen.','Spotpris när elen används.'],
  ['När marknaden stiger','Säkringarna kan dämpa uppgången.','Spotprisets uppgång får genomslag.'],
  ['När marknaden faller','Gjorda säkringar kan ligga över det nya marknadspriset.','Spotprisets nedgång får genomslag.'],
  ['Vad som återstår','Osäkrad del, förbrukningsmönster och kostnader enligt avtal.','Förbrukningsmönster och kostnader enligt avtal.']
 ]:s.contract==='quarter'?[]:[
  ['Pris i den här kalkylen','Samma manuellt angivna pris för alla månader.','Underlagets rörliga månadspriser.'],
  ['Budget','Prisscenariot kan användas som jämförelsepunkt.','Kostnaden följer pris och förbrukning.'],
  ['Att kontrollera',s.contract==='stable'?'Vad offerten för Stabil omfattar och hur länge den gäller.':'Bindningstid, tillägg och volymvillkor.','Påslag, avgifter och möjlighet att flytta användning.']
 ];
 const source=portfolio?(s.contract==='individual'?'https://www.kraftringen.se/foretag/el/vara-elavtal/portfoljforvaltning/':'https://www.kraftringen.se/foretag/el/vara-elavtal/poolportfolj/'):'https://www.kraftringen.se/foretag/el/vara-elavtal/avtalsvillkor/';
 return `<section class="sheet benefit-sheet"><p class="eyebrow">UPPLÄGGET I PRAKTIKEN</p><h2>Vad betyder ${c.label} för er?</h2><p class="benefit-intro">${v.intro}</p><div class="benefits">${v.benefits.map(([title,text],i)=>`<article><span class="benefit-number" aria-hidden="true">0${i+1}</span><h3>${title}</h3><p>${text}</p></article>`).join('')}</div><p class="tradeoff"><strong>Det här behöver ni också veta.</strong> ${caveat}</p>${rows.length?`<details><summary>Jämför egenskaper med kvartspris</summary><div class="comparison-table"><table><caption>Så skiljer sig avtalen – beskrivning, inte ett betyg</caption><thead><tr><th>Att jämföra</th><th>${c.label}</th><th>Kvartspris</th></tr></thead><tbody>${rows.map(row=>`<tr>${row.map((cell,i)=>i===0?`<th scope="row">${cell}</th>`:`<td>${cell}</td>`).join('')}</tr>`).join('')}</tbody></table></div></details>`:''}<div class="conversation-prompt"><span>FRÅGA ATT PRATA OM</span><p>${BRANCH_PROMPTS[s.business]}</p></div><details><summary>Om beskrivningen och underlaget</summary><p class="muted">Kvalitativa egenskaper är skilda från resultatet i kalkylen. Transparens kräver att prisdelar och avgifter redovisas tydligt, oavsett avtalsform. Individuell portfölj och båda poolerna har samma historiska siffror här i denna illustration; en aktiv strategi får inget extra simulerat resultat. Direkt och Stabil visas som förenklade prisscenarier utifrån offertens jämförpris. Direkt har separata månadssäkringspriser som inte räknas fram här.</p><a class="source-link" href="${source}" target="_blank" rel="noopener">Kraftringens produktinformation och villkor ↗</a></details></section>`;
}
