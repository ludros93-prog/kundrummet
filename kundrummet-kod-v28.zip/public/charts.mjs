import {MONTHS} from './model.mjs';
const fmt=(n,d=0)=>new Intl.NumberFormat('sv-SE',{minimumFractionDigits:d,maximumFractionDigits:d}).format(n);
function niceStep(span){const rough=Math.max(span/4,.01),p=10**Math.floor(Math.log10(rough)),v=rough/p;return (v<=1?1:v<=2?2:v<=2.5?2.5:v<=5?5:10)*p;}
function emptyMonths(r,x,top,height){return r.rows.filter(row=>!row.available).map(row=>`<rect x="${x(row.index)-20}" y="${top}" width="40" height="${height}" fill="#f0f4f6"/><text x="${x(row.index)}" y="${top+14}" fill="#647580" text-anchor="middle" font-size="11">—</text>`).join('');}
function monthLabels(x,height){return MONTHS.map((m,i)=>`<text x="${x(i)}" y="${height-6}" text-anchor="middle" fill="#526572" font-size="11">${m}</text>`).join('');}
export function priceChart(r,unit='ore',prefix='price',selected=null){
 const w=700,h=210,left=46,right=22,top=20,bottom=30,available=r.rows.filter(row=>row.available),keys=unit==='ore'?['variableRate','portfolioRate','fixedRate']:['variable','portfolio','fixed'],values=available.flatMap(row=>keys.map(k=>row[k])),step=niceStep(Math.max(0,...values)-Math.min(0,...values)),min=Math.floor(Math.min(0,...values)/step)*step,max=Math.max(step,Math.ceil(Math.max(0,...values)/step)*step),ph=h-top-bottom;
 const x=i=>left+i*(w-left-right)/11,y=v=>top+ph-(v-min)/(max-min)*ph,unitLabel=unit==='ore'?'öre/kWh':'kr/månad';
 let svg=`<svg viewBox="0 0 ${w} ${h}" role="img" aria-labelledby="${prefix}-title ${prefix}-desc"><title id="${prefix}-title">${unit==='ore'?'Månadspris':'Månadskostnad'} · ${r.periodLabel}</title><desc id="${prefix}-desc">Rörligt i korall, portfölj i blått och fastpris som streckad grå linje. ${unitLabel}, inklusive påslag och angivna kostnadstillägg. Saknade månader visas som streck. Exakta tal finns i månadstabellen.</desc>`;
 svg+=`<defs><linearGradient id="${prefix}-saving" gradientUnits="userSpaceOnUse" x1="0" y1="20" x2="0" y2="200"><stop stop-color="#fbc34e" stop-opacity=".5"/><stop offset="1" stop-color="#fbc34e" stop-opacity=".14"/></linearGradient><linearGradient id="${prefix}-extra" gradientUnits="userSpaceOnUse" x1="0" y1="20" x2="0" y2="200"><stop stop-color="#f8c3c6" stop-opacity=".65"/><stop offset="1" stop-color="#f8c3c6" stop-opacity=".2"/></linearGradient></defs>`;
 if(selected!==null)svg+=`<rect x="${x(selected)-21}" y="${top}" width="42" height="${ph}" rx="9" fill="#edf3f6"/>`;
 for(let v=min;v<=max+step*.01;v+=step)svg+=`<line x1="${left}" x2="${w-right}" y1="${y(v)}" y2="${y(v)}" stroke="#dde5e9" stroke-dasharray="3 5"/><text x="${left-8}" y="${y(v)+4}" text-anchor="end" fill="#526572" font-size="10">${fmt(unit==='ore'?v:v/1000,unit==='ore'?(step<1?2:step%1?1:0):(step%1000?1:0))}</text>`;
 // Split the band where the lines cross. Missing months never get bridged.
 for(let i=1;i<r.rows.length;i++){
  const a=r.rows[i-1],b=r.rows[i];if(!a.available||!b.available)continue;
  const da=a[keys[0]]-a[keys[1]],db=b[keys[0]]-b[keys[1]],points=[{x:x(a.index),v:a[keys[0]],p:a[keys[1]],d:da}];
  if(da*db<0){const t=da/(da-db),v=a[keys[0]]+t*(b[keys[0]]-a[keys[0]]);points.push({x:x(a.index)+t*(x(b.index)-x(a.index)),v,p:v,d:0});}
  points.push({x:x(b.index),v:b[keys[0]],p:b[keys[1]],d:db});
  for(let j=1;j<points.length;j++){const u=points[j-1],v=points[j],kind=(u.d+v.d)>=0?'saving':'extra';svg+=`<path data-gap="${kind}" d="M${u.x},${y(u.v)} L${v.x},${y(v.v)} L${v.x},${y(v.p)} L${u.x},${y(u.p)} Z" fill="url(#${prefix}-${kind})"/>`;}
 }
 if(selected!==null)svg+=`<line x1="${x(selected)}" x2="${x(selected)}" y1="${top}" y2="${top+ph}" stroke="#013c57" stroke-opacity=".35" stroke-dasharray="3 4"/>`;
 for(const [key,color,label,dash] of [[keys[2],'#8798a1','Fastpris',true],[keys[0],'#b84636','Rörligt',false],[keys[1],'#007aa3','Portfölj',false]]){
  let d='',active=false;for(const row of r.rows){if(!row.available){active=false;continue;}d+=`${active?'L':'M'}${x(row.index)},${y(row[key])} `;active=true;}
  svg+=`<path d="${d}" stroke="${color}" stroke-width="${dash?1.5:key===keys[1]?3.5:2.5}" ${dash?'stroke-dasharray="5 5"':''} fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;
  for(const row of available)svg+=`<circle cx="${x(row.index)}" cy="${y(row[key])}" r="${row.index===selected?5:2.5}" fill="white" stroke="${color}" stroke-width="${row.index===selected?2.5:1.5}"><title>${row.month}: ${label} ${fmt(row[key],2)} ${unitLabel}</title></circle>`;
 }
 for(const row of r.rows){if(!row.available)svg+=`<text x="${x(row.index)}" y="${top+ph-10}" text-anchor="middle" fill="#8798a1" font-size="13">—</text>`;else if(selected!==null)svg+=`<rect data-chart-month="${row.index}" x="${x(row.index)-22}" y="${top}" width="44" height="${ph}" fill="transparent" aria-hidden="true" style="cursor:pointer"><title>${row.month} · klicka för att jämföra</title></rect>`;}
 return svg+monthLabels(x,h)+'</svg>';
}
export function differenceChart(r,unit='ore',prefix='difference'){
 const w=700,h=178,left=46,right=15,top=26,bottom=29,key=unit==='ore'?'differenceRate':'difference',values=r.rows.filter(row=>row.available).map(row=>row[key]),extent=Math.max(unit==='ore'?1:100,...values.map(Math.abs))*1.28,ph=h-top-bottom;
 const x=i=>left+i*(w-left-right)/11,y=v=>top+ph/2-v/extent*ph/2,unitLabel=unit==='ore'?'öre/kWh':'kr';
 let svg=`<svg viewBox="0 0 ${w} ${h}" role="img" aria-labelledby="${prefix}-title ${prefix}-desc"><title id="${prefix}-title">Skillnad mot rörligt per månad i ${unitLabel}</title><desc id="${prefix}-desc">Positiva blå staplar är besparing med portfölj. Negativa korallfärgade staplar är merkostnad. Saknade månader ingår inte. Exakta tal finns i månadstabellen.</desc>`;
 svg+=emptyMonths(r,x,top,ph);
 svg+=`<line x1="${left-24}" x2="${w-right+10}" y1="${y(0)}" y2="${y(0)}" stroke="#a4b4bd"/><text x="${left-29}" y="${y(0)+3}" text-anchor="end" fill="#526572" font-size="10">0</text>`;
 for(const row of r.rows){if(!row.available)continue;const v=row[key],zero=Math.abs(v)<1e-8,color=zero?'#a4b4bd':v>0?'#007aa3':'#b84636',height=Math.abs(y(v)-y(0)),signed=(zero?'':v>0?'+':'−')+fmt(Math.abs(v),unit==='ore'?1:0);
  svg+=`<rect x="${x(row.index)-13}" y="${Math.min(y(v),y(0))}" width="26" height="${Math.max(zero?1:0,height)}" rx="3" fill="${color}"><title>${row.month}: ${zero?'Ingen skillnad':v>0?'Besparing':'Merkostnad'} ${fmt(Math.abs(row.differenceRate),2)} öre/kWh · ${fmt(Math.abs(row.difference),2)} kr</title></rect><text x="${x(row.index)}" y="${v>=0?y(v)-7:y(v)+14}" text-anchor="middle" fill="${color}" font-size="10" font-weight="600">${signed}</text>`;
 }
 return svg+monthLabels(x,h)+'</svg>';
}

const FULL_MONTHS=['Januari','Februari','Mars','April','Maj','Juni','Juli','Augusti','September','Oktober','November','December'];
const magnitude=n=>Math.abs(n)>1e-8&&Math.abs(n)<.005?'< 0,01':fmt(Math.abs(n),2);
export function monthFocus(r,index){
 const row=r.rows[index];
 if(!row?.available)return '<div class="month-empty"><strong>Här syns månadens jämförelse.</strong><p>Lägg in förbrukning för en månad med priser för att se skillnaden.</p></div>';
 const kind=Math.abs(row.differenceRate)<1e-8?'equal':row.differenceRate>0?'saving':'extra';
 const title=row.volume===0?'Prisskillnad · 0 kWh':{saving:'Besparing med portfölj',extra:'Merkostnad med portfölj',equal:'Samma kostnad'}[kind];
 return `<div class="month-focus-heading"><div><span>VALD MÅNAD</span><h4>${FULL_MONTHS[index]} ${r.periodLabel}</h4></div><p>${fmt(row.volume,row.volume%1?2:0)} <span>kWh</span></p></div><div class="month-metrics"><div class="month-metric"><span><i class="line variable"></i>Rörligt</span><strong>${fmt(row.variable,2)} <small>kr</small></strong><p>${fmt(row.variableRate,2)} öre/kWh</p></div><div class="month-metric"><span><i class="line secured"></i>Portfölj</span><strong>${fmt(row.portfolio,2)} <small>kr</small></strong><p>${fmt(row.portfolioRate,2)} öre/kWh</p></div><div class="month-result" data-kind="${kind}"><span>${title}</span><strong>${magnitude(row.difference)} <small>kr</small></strong><p>${magnitude(row.differenceRate)} öre/kWh${kind==='equal'?'':kind==='saving'?' lägre':' högre'}</p></div></div>`;
}
export function monthButtons(r,unit='ore',selected=null){
 const key=unit==='ore'?'differenceRate':'difference',extent=Math.max(1,...r.rows.filter(row=>row.available).map(row=>Math.abs(row[key])));
 return r.rows.map(row=>{
  if(!row.available)return `<button type="button" class="month-button unavailable" disabled aria-label="${FULL_MONTHS[row.index]}: underlag saknas"><span class="month-bar-space" aria-hidden="true"><span class="month-missing">—</span></span><span class="month-value" aria-hidden="true">—</span><span class="month-name">${row.month}</span></button>`;
  const v=row[key],zero=Math.abs(v)<1e-8,kind=zero?'equal':v>0?'saving':'extra',signed=(zero?'':v>0?'+':'−')+fmt(Math.abs(v)/(unit==='kr'?1000:1),1),height=zero?2:Math.max(2,Math.abs(v)/extent*35);
  return `<button type="button" class="month-button" data-month-index="${row.index}" data-kind="${kind}" aria-pressed="${row.index===selected}" aria-controls="monthFocus" aria-label="${FULL_MONTHS[row.index]}: ${zero?'ingen skillnad':v>0?'besparing':'merkostnad'} ${magnitude(row.differenceRate)} öre per kWh, ${magnitude(row.difference)} kronor"><span class="month-bar-space" aria-hidden="true"><i style="height:${height}px"></i></span><span class="month-value" aria-hidden="true">${signed}</span><span class="month-name" aria-hidden="true">${row.month}</span></button>`;
 }).join('');
}
