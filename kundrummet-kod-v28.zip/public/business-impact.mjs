// Presentation only: all values derive from the same included comparison months.
export const BUSINESS_TYPES=Object.freeze({
 company:{label:'Företag',subject:'verksamheten',context:'En tydligare bild av vad elvalet betyder för er kostnadsbudget.'},
 brf:{label:'BRF',subject:'föreningen',context:'Se skillnaden för föreningen och, om ni vill, per lägenhet.'},
 hotel:{label:'Hotell',subject:'hotellet',context:'Ett konkret belopp att ta med i hotellets driftbudget.'},
 industry:{label:'Industri',subject:'produktionen',context:'Elkostnaden för den förbrukning ni har jämfört. Ändrad produktion behöver en uppdaterad förbrukningsprofil.'},
 farm:{label:'Lantbruk',subject:'lantbruket',context:'Förbrukningens fördelning över året avgör utfallet. Utgå från månaderna då elen faktiskt används.'},
 shop:{label:'Butik',subject:'butiken',context:'Ett konkret belopp att ta med i butikens kostnadsbudget.'}
});
export function validBusiness(b){return b===undefined||!!b&&typeof b==='object'&&!Array.isArray(b)&&Object.hasOwn(BUSINESS_TYPES,b.type)&&(b.apartments===null||Number.isInteger(b.apartments)&&b.apartments>=1&&b.apartments<=100000);}
const format=(n,d=2)=>new Intl.NumberFormat('sv-SE',{minimumFractionDigits:d,maximumFractionDigits:d}).format(n);
const magnitude=n=>Math.abs(n)>1e-8&&Math.abs(n)<.005?'< 0,01':format(Math.abs(n));
export function businessImpact(r,s){
 const business=validBusiness(s.business)&&s.business?s.business:{type:'company',apartments:null},type=BUSINESS_TYPES[business.type],perApartment=business.type==='brf'&&business.apartments!==null;
 const kind=!r.volume?'empty':Math.abs(r.difference)<1e-8?'equal':r.difference>0?'saving':'extra';
 const direction=kind==='extra'?'högre':kind==='equal'?'oförändrad':'lägre';
 const amount=r.volume?(perApartment?r.difference/business.apartments:r.difference):null;
 const unit=perApartment?'kr per lägenhet':'kr';
 const caption=perApartment?`${direction[0].toUpperCase()+direction.slice(1)} beräknad elkostnad`:`${direction[0].toUpperCase()+direction.slice(1)} beräknad elkostnad för ${type.subject}`;
 const percent=r.volume&&r.variable>0?r.difference/r.variable*100:null;
 const percentText=percent===null?'':kind==='equal'?'Samma beräknade elkostnad som rörligt':`${format(Math.abs(percent),1)} % ${direction} elkostnad än rörligt`;
 const scope=`${s.period} · ${r.count} av 12 månader · ${format(r.volume/1000,r.volume%1000?1:0)} MWh i jämförelsen${s.sources[s.period]==='estimated'?' · uppskattad förbrukning':''}.`;
 const basis=perApartment?`Jämnt fördelat på ${format(business.apartments,0)} lägenheter. Ett räkneexempel, inte en beräknad ändring av månadsavgiften.`:type.context;
 const sensitivity=`1 öre/kWh motsvarar ${format(r.volume/100)} kr för er förbrukning i jämförelsen.`;
 const total=`${magnitude(r.difference)} kr ${kind==='extra'?'mer':kind==='equal'?'i skillnad':'mindre'} för ${type.subject} jämfört med rörligt.`;
 const result=amount===null?'Lägg in förbrukning för att se effekten.':`${magnitude(amount)} ${unit} · ${caption.toLowerCase()}.`;
 const lines=[`Verksamhet: ${type.label}.`,result,...(perApartment?[total]:percentText?[percentText+'.']:[]),sensitivity,basis,scope,'Exklusive moms, elnät och energiskatt. Ingen prognos.'];
 return {business,type,kind,amount,unit,caption,percent,percentText,scope,basis,sensitivity,total,result,lines,displayAmount:amount===null?'—':magnitude(amount)};
}
export function renderBusiness(r,s){
 const v=businessImpact(r,s),$=id=>document.getElementById(id);
 $('businessType').value=v.business.type;
 if(document.activeElement!==$('businessApartments')){$('businessApartments').value=v.business.apartments??'';$('businessApartments').removeAttribute('aria-invalid');$('businessApartmentError').hidden=true;}
 $('businessApartmentField').hidden=v.business.type!=='brf';
 $('businessImpact').dataset.kind=v.kind;
 $('businessImpactIcon').dataset.type=v.business.type;
 const icon={company:'M4 21V7h16v14M8 7V3h8v4M9 11h1m4 0h1m-6 4h1m4 0h1m-5 6v-3h4v3',brf:'M4 21V3h11v18M15 10h5v11M8 7h3m-3 4h3m-3 4h3m-3 6v-3h3v3',hotel:'M3 20V9m18 11V9M3 15h18M6 15v-4h5v4m0-4h7v4M5 5h14',industry:'M3 21V10l6 4V9l6 5V7h6v14H3m14-14V3h3v4M7 18h1m4 0h1m4 0h1',farm:'M3 21V11l9-8 9 8v10H3m5 0v-9h8v9M8 12l8 9m0-9-8 9',shop:'M4 10v11h16V10M3 10l2-7h14l2 7M3 10c0 4 6 4 6 0 0 4 6 4 6 0 0 4 6 4 6 0M8 21v-6h4v6'};
 $('businessIconPath').setAttribute('d',icon[v.business.type]);
 $('businessImpactAmount').textContent=v.displayAmount;$('businessImpactUnit').textContent=v.unit;
 $('businessImpactCaption').textContent=v.kind==='empty'?'Lägg in förbrukning för att se effekten':v.caption;
 $('businessImpactSecondary').textContent=v.business.type==='brf'&&v.business.apartments!==null?v.total:v.percentText;
 $('businessImpactSecondary').hidden=!$('businessImpactSecondary').textContent||v.kind==='empty';
 $('businessImpactSensitivity').textContent=v.sensitivity;$('businessImpactSensitivity').hidden=v.kind==='empty';
 $('businessImpactContext').textContent=v.basis;$('businessImpactScope').textContent=v.scope;
}
