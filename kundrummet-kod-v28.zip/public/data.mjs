export const DATA = {
  "id": "ludwig-2025-2026-v1",
  "sourceName": "Jämförelse_Estimerade_priser_portfölj_mot_rörligt_kvartspris_och_fastpris_2025_2026_ludwig.xlsx",
  "sha256": "a368dee5d7ba6cdf0112ae35a0a10ef76030ec3c96e0f20d7569bae89531ec10",
  "sheet": "Elförbrukning",
  "parameters": {
    "portfolioFee": 2.0,
    "variableFee": 2.4,
    "fixed": 101.4
  },
  "periods": {
    "2025": {
      "label": "2025",
      "count": 12,
      "columns": {
        "volume": "B",
        "hedged": "T",
        "spot": "U",
        "running": "V",
        "weighting": "W"
      },
      "volume": [
        10000.0,
        11000.0,
        12000.0,
        13000.0,
        14000.0,
        15000.0,
        16000.0,
        17000.0,
        18000.0,
        19000.0,
        20000.0,
        21000.0
      ],
      "hedged": [
        83.49,
        81.92,
        62.46,
        50.54,
        39.91,
        37.41,
        39.13,
        46.57,
        53.4,
        60.83,
        77.21,
        85.67
      ],
      "spot": [
        76.11,
        103.87,
        60.46,
        58.35,
        60.01,
        40.7,
        46.37,
        73.23,
        70.6,
        71.25,
        80.7,
        64.88
      ],
      "running": [
        6.98,
        9.56,
        6.89,
        5.98,
        4.0,
        4.3,
        4.84,
        5.55,
        7.59,
        6.11,
        12.07,
        5.14
      ],
      "weighting": [
        3.27,
        5.72,
        3.24,
        2.35,
        0.36,
        0.74,
        1.19,
        1.8,
        3.89,
        2.4,
        8.53,
        1.73
      ]
    },
    "2026": {
      "label": "2026",
      "count": 9,
      "columns": {
        "volume": "K",
        "hedged": "Z",
        "spot": "AA",
        "running": "AB",
        "weighting": "AC"
      },
      "volume": [
        10000.0,
        11000.0,
        12000.0,
        13000.0,
        14000.0,
        15000.0,
        16000.0,
        17000.0,
        18000.0,
        null,
        null,
        null
      ],
      "hedged": [
        95.02,
        97.25,
        72.78,
        53.34,
        50.29,
        47.9,
        42.42,
        47.95,
        52.92,
        null,
        null,
        null
      ],
      "spot": [
        112.99,
        113.28,
        84.58,
        66.55,
        94.64,
        103.72,
        86.44,
        80.47,
        120.2,
        null,
        null,
        null
      ],
      "running": [
        5.73,
        5.83,
        9.0,
        7.77,
        9.07,
        6.73,
        5.95,
        7.98,
        11.67,
        null,
        null,
        null
      ],
      "weighting": [
        2.57,
        2.65,
        4.42,
        3.29,
        4.45,
        2.05,
        1.33,
        3.37,
        6.85,
        null,
        null,
        null
      ]
    }
  }
};
