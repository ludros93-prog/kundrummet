import {agreementErrors,customerMonth,customerReferenceLabel} from './customer-agreement.mjs';
import {DATA,defaults,calculate} from './model.mjs';
export const CONTRACTS={
 "individual": {
  "label": "Individuell portfölj",
  "kind": "portfolio",
  "hint": "En egen inköpsplan utifrån er förbrukning och risknivå.",
  "fit": "För er som behöver anpassa inköpen till verksamheten.",
  "variation": "Osäkrad volym, förbrukningsmönster och avgifter påverkar slutpriset."
 },
 "safe": {
  "label": "Pool Trygg",
  "kind": "portfolio",
  "hint": "Gemensamma inköp som sprids över tid för en jämnare prisbild.",
  "fit": "För er som vill ha en färdig strategi och mindre egen marknadsbevakning.",
  "variation": "Priset följer poolens gemensamma säkringar. Osäkrad del och avtalskostnader återstår."
 },
 "offensive": {
  "label": "Pool Offensiv",
  "kind": "portfolio",
  "hint": "Gemensam prissäkring med aktiv förvaltning av delar av inköpen.",
  "fit": "För er som accepterar mer variation för möjligheten till ett bättre utfall.",
  "variation": "Aktiva beslut kan ge både bättre och sämre utfall än en ren indexstrategi."
 },
 "direct": {
  "label": "Kraftringen Direkt",
  "kind": "manual",
  "hint": "Säkra vid ett tillfälle, med ett säkringspris för varje avtalsmånad.",
  "fit": "För er som vill känna månadens säkringsnivå och har förutsägbar elanvändning.",
  "variation": "Osäkrad del, faktisk volym och när elen används påverkar slutpriset."
 },
 "stable": {
  "label": "Kraftringen Stabil",
  "kind": "manual",
  "hint": "Ett gemensamt säkringspris, vägt efter er månadsförbrukning.",
  "fit": "För er som vill planera med en gemensam säkringsnivå och har stabil förbrukningsprofil.",
  "variation": "Säkringspriset är gemensamt. Förbrukning, profil, osäkrad del och avgifter kan ändå ändra fakturan."
 },
 "quarter": {
  "label": "Kvartspris",
  "kind": "variable",
  "hint": "Följ marknaden och påverka kostnaden genom när ni använder el.",
  "fit": "För er som kan bära prissvängningar och eventuellt flytta elanvändningen.",
  "variation": "Spotpris och er användning under varje kvart styr kostnaden, tillsammans med avtalets tillägg."
 },
 "fixed": {
  "label": "Fastpris",
  "kind": "manual",
  "hint": "Ett avtalat pris för den del och period som omfattas av offerten.",
  "fit": "För er som prioriterar ett känt avtalat pris framför att följa marknaden.",
  "variation": "Förbrukning, volymvillkor och tillägg kan fortfarande påverka fakturan."
 }
};
export const manualPriceKey=contract=>({stable:"stablePrice",direct:"directPrice",fixed:"fixedPrice"}[contract]);
export const MEETING_TEXT_FIELDS={goal:1000,recommendation:2000,checks:2000,owner:100};
export const validFollowUp=v=>v===''||typeof v==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(v)&&!Number.isNaN(Date.parse(v))&&new Date(v).toISOString().slice(0,10)===v;
export const YEARS=['2025','2026'];
export const sameProfiles=s=>s.profiles['2025'].every((v,i)=>v===s.profiles['2026'][i]);
export function copyProfile(s,from,to){
 if(!YEARS.includes(from)||!YEARS.includes(to))throw Error('Ogiltigt profilår.');
 s.profiles[to]=[...s.profiles[from]];s.sources[to]=s.sources[from];s.estimates??={};
 if(s.estimates[from])s.estimates[to]=structuredClone(s.estimates[from]);else delete s.estimates[to];
}
export function syncSharedProfile(s,from){if(s.consumptionMode==='shared')copyProfile(s,from,YEARS.find(y=>y!==from));}
export function normalizeMeeting(s){
 const next=structuredClone(s);
 for(const key of Object.keys(MEETING_TEXT_FIELDS))next[key]??='';next.followUp??='';next.directPrice??=null;next.comparisonMode??='reference';
 if(next.consumptionMode===undefined){
  const filled=YEARS.filter(y=>next.profiles[y].some(v=>v!==null));
  next.consumptionMode=sameProfiles(next)||filled.length<=1?'shared':'separate';
  if(next.consumptionMode==='shared')syncSharedProfile(next,filled[0]??'2025');
 }
 return next;
}
export function yearsFor(period){if(period==='both')return YEARS;if(YEARS.includes(period))return [period];throw Error('Välj ett giltigt år.');}
export function initialMeeting(){return {version:1,comparisonMode:'reference',consumptionMode:'shared',customer:'',business:'company',seller:'Ludwig Rosenberg',period:'2025',contract:null,profiles:{'2025':Array(12).fill(null),'2026':Array(12).fill(null)},sources:{'2025':'own','2026':'own'},hedge:80,portfolioFee:DATA.parameters.portfolioFee,variableFee:DATA.parameters.variableFee,stablePrice:null,fixedPrice:null,directPrice:null,goal:'',recommendation:'',checks:'',owner:'',followUp:'',notes:'',next:''};}
export function validMeeting(s){return !!s&&s.version===1&&(s.consumptionMode===undefined||['shared','separate'].includes(s.consumptionMode))&&typeof s.customer==='string'&&s.customer.length<=120&&typeof s.seller==='string'&&s.seller.length<=100&&['company','brf','hotel','industry','farm','shop','transport','property','other'].includes(s.business)&&['2025','2026','both'].includes(s.period)&&(s.contract===null||Object.hasOwn(CONTRACTS,s.contract))&&YEARS.every(y=>Array.isArray(s.profiles?.[y])&&s.profiles[y].length===12&&s.profiles[y].every(v=>v===null||Number.isFinite(v)&&v>=0&&v<=100000000)&&['own','estimated','file'].includes(s.sources?.[y]))&&['hedge','portfolioFee','variableFee'].every(k=>Number.isFinite(s[k])&&s[k]>=0&&s[k]<=100)&&['stablePrice','fixedPrice'].every(k=>s[k]===null||Number.isFinite(s[k])&&s[k]>=0&&s[k]<=500)&&(s.directPrice===undefined||s.directPrice===null||Number.isFinite(s.directPrice)&&s.directPrice>=0&&s.directPrice<=500)&&Object.entries(MEETING_TEXT_FIELDS).every(([k,max])=>s[k]===undefined||typeof s[k]==='string'&&s[k].length<=max)&&(s.followUp===undefined||validFollowUp(s.followUp))&&typeof s.notes==='string'&&s.notes.length<=10000&&typeof s.next==='string'&&s.next.length<=1000&&(s.consumptionMode!=='shared'||sameProfiles(s));}
export function meetingResult(s){
 if(!validMeeting(s)||!s.contract)throw Error('Välj avtal och kontrollera era uppgifter.');
 const customer=s.comparisonMode==='customer',a=s.customerAgreement;
 if(customer){
  const errors=agreementErrors(a,{forComparison:true});
  if(typeof a?.customer!=='string'||a.customer.trim().toLocaleLowerCase('sv')!==s.customer.trim().toLocaleLowerCase('sv'))errors.push('Mötet och prisuppgiften gäller olika kunder.');
  if(!Number.isFinite(s.selectedMonthlyFee)||s.selectedMonthlyFee<0||s.selectedMonthlyFee>100000)errors.push('Ange förslagets månadsavgift.');
  if(!s.comparisonScopeChecked||s.comparisonArea==='unknown'||s.comparisonArea!==a?.area)errors.push('Bekräfta samma elområde och kostnadsomfattning.');
  if(errors.length)throw Error(errors.join(' '));
 }
 const kind=CONTRACTS[s.contract].kind,manual=s[manualPriceKey(s.contract)]??null;
 if(kind==='manual'&&manual===null)throw Error('Ange ett pris i öre/kWh för det valda avtalet.');
 const years=yearsFor(s.period),base=defaults(),rows=[];
 for(const year of years){
  const r=calculate({...base,period:year,profiles:s.profiles,hedge:s.hedge,portfolioFee:s.portfolioFee,variableFee:s.variableFee});
  for(const row of r.rows){
   const key=`${year}-${String(row.index+1).padStart(2,'0')}`;
   const ref=customer?customerMonth(a,key,row.volume,{estimated:s.sources[year]==='estimated'}):null;
   const selectedAvailable=customer&&kind==='manual'?row.volume!==null:row.available;
   const available=selectedAvailable&&(!customer||ref.available);
   const unitRate=!available?null:kind==='portfolio'?row.portfolioRate:kind==='variable'?row.variableRate:manual;
   const selected=available?row.volume*unitRate/100+(customer?s.selectedMonthlyFee:0):null;
   rows.push({...row,available,year,label:`${row.month} ${year}`,selectedRate:available?(row.volume?selected/row.volume*100:unitRate):null,selected,
    ...(customer?{variable:available?ref.cost:null,variableRate:available?ref.rate:null,missingReason:!selectedAvailable?'Förslagets pris eller förbrukning saknas':ref.reason,selectedMonthlyFee:s.selectedMonthlyFee}:{} )});
  }
 }
 const available=rows.filter(r=>r.available),sum=k=>available.reduce((a,r)=>a+r[k],0),volume=sum('volume'),selected=sum('selected'),variable=sum('variable');
 return {referenceLabel:customerReferenceLabel(s),customerComparison:customer,rows,years,available,count:available.length,totalMonths:rows.length,volume,selected,variable,selectedRate:volume?selected/volume*100:null,variableRate:volume?variable/volume*100:null,difference:variable-selected,differenceRate:volume?(variable-selected)/volume*100:null,periodLabel:s.period==='both'?'2025 och 2026':s.period};
}
