import {businessImpact,renderBusiness} from './business-impact.mjs';
import {initMobile,renderMobile,syncMobileMonth} from './mobile-app.mjs';
import {MONTHS,DATA,hasMonthlyPrices,PROFILE_SHAPES,annualProfile,profileSourceLabel,defaults,calculate,parseProfile,validateState,migrateLegacy} from './model.mjs';
import {buildCustomerEmail,emailFile,mailtoLink,sellerNotesTitle,validEmail} from './customer-email.mjs';
import {priceChart,differenceChart,monthButtons,monthFocus} from './charts.mjs';
const $=id=>document.getElementById(id),fmt=(n,d=0)=>n===null?'—':new Intl.NumberFormat('sv-SE',{maximumFractionDigits:d,minimumFractionDigits:d}).format(n),esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let shareSnapshot=null;
let chartUnit='ore',selectedMonth=null,chartPeriod=null;
let state=defaults(),pendingImport=null,profileImported=false,toastTimer,canSave=true,migrated=false;
let profileMode='monthly';
const cleanState=s=>JSON.parse(JSON.stringify(s));
try{const saved=JSON.parse(localStorage.getItem('kundrum-v2'));if(validateState(saved))state=cleanState(saved);else{const old=JSON.parse(localStorage.getItem('kundrum-v1'));const next=migrateLegacy(old);if(next){state=next;migrated=true;}}}catch{}
function save(){try{localStorage.setItem('kundrum-v2',JSON.stringify(state));canSave=true;$('saveStatus').textContent='Sparat i den här webbläsaren';}catch{canSave=false;$('saveStatus').textContent='Kunde inte spara lokalt – exportera kundrummet';}}
function toast(msg){$('toast').textContent=msg;$('toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.remove('show'),5000);}
function setControls(){for(const k of ['consumption','hedge','fixed','portfolioFee','variableFee','notes','next','date','choice'])$(k).value=state[k];$('sellerName').value=state.sellerName||'Ludwig Rosenberg';}
function signed(n,d=2){return n===null?'—':(Math.abs(n)<1e-8?'':n>0?'+':'−')+fmt(Math.abs(n),d);}
function differenceKind(r){return !r.volume?'empty':Math.abs(r.differenceRate)<1e-8?'equal':r.difference>0?'saving':'extra';}
function savingsTitle(r){return {empty:'Lägg in förbrukning för att jämföra',equal:'Samma kostnad med båda alternativen',saving:'Så mycket sparar ni med portfölj',extra:'Så mycket mer kostar portfölj'}[differenceKind(r)];}
function savingsValue(n){return n===null?'—':Math.abs(n)>1e-8&&Math.abs(n)<.005?'< 0,01':fmt(Math.abs(n),2);}
function renderCharts(r){
 if(chartPeriod!==state.period){selectedMonth=null;chartPeriod=state.period;}
 if(!r.rows[selectedMonth]?.available)selectedMonth=r.rows.filter(row=>row.available).at(-1)?.index??null;
 const focusedMonth=document.activeElement?.dataset.monthIndex;
 $('costChart').innerHTML=priceChart(r,chartUnit,'price',selectedMonth);
 const marker=$('costChart').querySelector(`[data-chart-month="${selectedMonth}"]`);
 if(marker){const b=marker.getBoundingClientRect(),container=$('costChart');container.scrollLeft+=b.x+b.width/2-container.getBoundingClientRect().x-container.clientWidth/2;}
 $('monthButtons').innerHTML=monthButtons(r,chartUnit,selectedMonth);
 $('monthFocus').innerHTML=monthFocus(r,selectedMonth);
 const first=r.rows[selectedMonth];
 $('priceBreakdown').innerHTML=first?`<span class="breakdown-heading">Så blir portföljpriset i ${first.month.toLowerCase()}</span><div><span><strong>${fmt(first.hedgedPart,2)}</strong>Säkrat · ${state.hedge} %</span><b>+</b><span><strong>${fmt(first.floatingPart,2)}</strong>Rörligt · ${100-state.hedge} %</span><b>+</b><span><strong>${fmt(first.cost+state.portfolioFee,2)}</strong>Tillägg & påslag</span><b>=</b><span class="breakdown-total"><strong>${fmt(first.portfolioRate,2)}</strong>öre/kWh</span></div>`:'';
 $('priceChartHeading').textContent=chartUnit==='ore'?'Pris per månad':'Kostnad per månad';
 $('chartUnitLabel').textContent=chartUnit==='ore'?'öre/kWh':'tkr / månad';
 $('differenceUnitLabel').textContent=chartUnit==='ore'?'öre/kWh':'tkr / månad';
 $('chartAvailability').textContent=r.count<12?`${12-r.count} månader saknar underlag`:'Alla 12 månader har underlag';
 document.querySelectorAll('[data-chart-unit]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.chartUnit===chartUnit)));
 syncMobileMonth(selectedMonth);
 if(focusedMonth!==undefined)$('monthButtons').querySelector(`[data-month-index="${focusedMonth}"]`)?.focus({preventScroll:true});
}
function selectMonth(index,reveal=false){if(!calculate(state).rows[index]?.available)return;selectedMonth=index;renderCharts(calculate(state));if(reveal&&!matchMedia('(max-width:700px)').matches&&matchMedia('(max-width:850px)').matches)$('monthFocus').scrollIntoView({block:'start',behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'instant':'smooth'});}

function tableRows(r){return r.rows.map(row=>`<tr${row.available?'':' class="missing"'}><td>${row.month}</td><td>${fmt(row.volume,1)}</td>${row.available?`<td>${fmt(row.variableRate,2)}</td><td>${fmt(row.portfolioRate,2)}</td><td class="${row.differenceRate>=0?'positive':'negative'}">${signed(row.differenceRate)}</td><td>${fmt(row.variable,2)}</td><td>${fmt(row.portfolio,2)}</td><td class="${row.difference>=0?'positive':'negative'}">${signed(row.difference)}</td><td>${fmt(row.fixed,2)}</td>`:'<td colspan="7">Underlag saknas · ingår inte</td>'}</tr>`).join('');}
function totalRow(r){return `<tr><td>Totalt / vägt snitt</td><td>${fmt(r.volume,1)}</td><td>${fmt(r.variableRate,2)}</td><td>${fmt(r.portfolioRate,2)}</td><td>${signed(r.differenceRate)}</td><td>${fmt(r.variable,2)}</td><td>${fmt(r.portfolio,2)}</td><td>${signed(r.difference)}</td><td>${fmt(r.fixed,2)}</td></tr>`;}
function render(){
 const r=calculate(state),p=DATA.periods[state.period],profile=state.profiles[state.period],total=profile.reduce((a,v)=>a+(v??0),0),peak=Math.max(0,...profile.map(v=>v??0));
 const seller=state.sellerName||'Ludwig Rosenberg';$('advisorName').textContent=seller;$('advisorInitials').textContent=seller.split(/\s+/).map(word=>word[0]).filter(Boolean).slice(0,2).join('').toUpperCase();$('notesLabel').textContent=sellerNotesTitle(seller);
 $('customerLabel').textContent=state.customer;$('annualVolume').innerHTML=`${fmt(r.volume/1000,r.volume%1000?1:0)} <small>MWh</small>`;
 const full=profile.every(v=>v!==null),winter=total?[0,1,2,9,10,11].reduce((a,i)=>a+(profile[i]??0),0)/total:0;
 $('seasonLabel').textContent=!full?'Del av året':!total?'Ingen förbrukning':winter>.55?'Vintertung':winter<.45?'Sommartung':'Jämn över året';
 $('sourceLabel').textContent=p.label;$('profileSource').textContent=profileSourceLabel(state);
 $('profileEstimateNote').hidden=state.sources[state.period]!=='estimated';$('profileEstimateNote').textContent=state.sources[state.period]==='estimated'?profileSourceLabel(state):'';
 $('profileTotal').textContent=fmt(total/1000,1)+' MWh';$('peakMonth').textContent=peak?MONTHS[profile.indexOf(peak)]+' · '+fmt(peak/1000,1)+' MWh':'—';
 $('profileChart').innerHTML=profile.map((v,i)=>`<div class="profile-bar ${v===peak?'peak':''} ${v===null?'missing':''}" title="${MONTHS[i]}: ${v===null?'saknas':fmt(v)+' kWh'}"><span class="value">${v===null?'—':fmt(v/1000,1)}</span><div class="bar" style="height:${peak?(v??0)/peak*112:0}px"></div><span class="month">${MONTHS[i]}</span></div>`).join('');
 document.querySelectorAll('[data-period]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.period===state.period)));
 $('scenarioDescription').textContent=`${r.count} av 12 månader med komplett underlag. Månadspriser från ditt Excelunderlag.`;
 for(const [key,id] of [['variable','variable'],['portfolio','secured'],['fixed','fixed']]){$(id+'Total').textContent=fmt(r[key],2)+' kr';$(id+'Unit').innerHTML=`${fmt(r[key+'Rate'],2)} <small>öre/kWh</small>`;}
 $('savingsPanel').dataset.kind=differenceKind(r);$('savingsTitle').textContent=savingsTitle(r);$('savingsOre').textContent=savingsValue(r.differenceRate);$('savingsMoney').textContent=savingsValue(r.volume?r.difference:null);$('savingsContext').textContent=r.volume?`Jämfört med rörligt, för samma ${fmt(r.volume)} kWh under ${r.periodLabel}.`:'Ingen förbrukning att jämföra för valt år.';
 $('hedgeExplanation').textContent=`${state.hedge} % av volymen prissäkras i jämförelsen. Förbrukningsprofil och andra kostnader påverkar fortfarande slutpriset.`;
 $('consumptionOutput').textContent=state.consumption+' %';$('hedgeOutput').textContent=state.hedge+' %';$('floatingShare').textContent=100-state.hedge+' % osäkrat';
 $('consumption').style.setProperty('--fill',(state.consumption-50)+'%');$('hedge').style.setProperty('--fill',state.hedge+'%');
 const diff=(n,against)=>Math.abs(n)<.005?`lika hög som med ${against}`:`${fmt(Math.abs(n))} kr ${n>0?'lägre':'högre'} än ${against}`;
 $('insightText').textContent=r.volume?`Med ${state.hedge} % säkring blir portföljens beräknade kostnad ${diff(r.difference,'rörligt')} och ${diff(r.fixedDifference,'fastpris')} för perioden.`:'Ingen förbrukning kan beräknas för valt år. Lägg in månadsvärden för att jämföra.';

 renderCharts(r);$('costRows').innerHTML=tableRows(r);$('costFoot').innerHTML=totalRow(r);
 $('priceRows').innerHTML=MONTHS.map((m,i)=>!hasMonthlyPrices(p,i)?`<tr class="missing"><td>${m}</td><td colspan="6">Prisunderlag saknas</td></tr>`:`<tr><td>${m}</td>${[p.hedged[i],p.spot[i],p.running[i],p.weighting[i],p.running[i]-p.weighting[i],state.hedge/100*p.hedged[i]+(1-state.hedge/100)*p.spot[i]+p.running[i]-p.weighting[i]+state.portfolioFee].map(v=>`<td>${fmt(v,2)}</td>`).join('')}</tr>`).join('');
 renderBusiness(r,state);renderMobile(r,state);
 $('sourceFile').textContent=`Källa: ${DATA.sourceName} · flik ${DATA.sheet}. Säkrat: ${p.columns.hedged}. Rörligt: ${p.columns.spot}. Kostnadstillägg: ${p.columns.running} − ${p.columns.weighting}.`;
}
function dialogPeriod(){return pendingImport?.period??state.period;}
function fillProfile(p){$('profileTitle').textContent='Förbrukning · '+DATA.periods[dialogPeriod()].label;$('monthInputs').innerHTML=MONTHS.map((m,i)=>`<label for="month${i}">${m} (kWh)<input id="month${i}" type="number" min="0" max="100000000" step="any" aria-describedby="consumptionUnitNote" placeholder="Saknas" value="${p[i]??''}">${!hasMonthlyPrices(DATA.periods[dialogPeriod()],i)?'<span class="month-price-note">Pris saknas</span>':''}</label>`).join('');updateDialogTotal();}
function readAnnualDraft(){
 const raw=$('annualConsumption').value.trim().replace(/\s/g,'').replace(',','.');
 const value=/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(raw)?Number(raw):NaN,annualKwh=value*($('annualUnit').value==='mwh'?1000:1),shape=document.querySelector('input[name="profileShape"]:checked').value;
 const profile=annualProfile(annualKwh,shape);
 return {profile,estimate:{annualKwh:Math.round(annualKwh*100)/100,shape,adjusted:false}};
}
function updateAnnualPreview(){
 try{
  const {profile,estimate}=readAnnualDraft(),p=DATA.periods[dialogPeriod()],included=profile.reduce((sum,v,i)=>sum+(hasMonthlyPrices(p,i)?v:0),0);
  $('annualProfileError').hidden=true;$('annualConsumption').setAttribute('aria-invalid','false');$('annualPreview').hidden=false;
  $('annualPreviewSummary').textContent=`${fmt(estimate.annualKwh,2)} kWh/år = ${fmt(estimate.annualKwh/1000,2)} MWh/år · ${PROFILE_SHAPES[estimate.shape].label}`;
  const priceCount=MONTHS.filter((_,i)=>hasMonthlyPrices(p,i)).length;
  $('annualPeriodNote').textContent=priceCount<12?`Årsvärdet fördelas över alla 12 månader. ${priceCount} månader har kompletta priser: ${fmt(included,2)} kWh ingår i jämförelsen. Månader utan priser ingår inte.`:'Alla 12 månader ingår i jämförelsen. Årssumman bevaras vid fördelningen.';
  $('annualPeriodNote').textContent+=' Visas före förbrukningsreglagets justering.';
  const weights=PROFILE_SHAPES[estimate.shape].weights,sum=weights.reduce((a,v)=>a+v,0);
  $('annualPreviewRows').innerHTML=MONTHS.map((m,i)=>`<tr><td>${m}${!hasMonthlyPrices(p,i)?' · pris saknas':''}</td><td>${fmt(weights[i]/sum*100,estimate.shape==='even'?2:0)} %</td><td>${fmt(profile[i],2)}</td></tr>`).join('');
  if(profileMode==='annual')$('applyProfile').disabled=false;
  return true;
 }catch(err){
  $('annualPreview').hidden=true;const show=$('annualConsumption').value.trim()!=='';$('annualProfileError').hidden=!show;$('annualProfileError').textContent=err.message;$('annualConsumption').setAttribute('aria-invalid',String(show));
  if(profileMode==='annual')$('applyProfile').disabled=true;
  return false;
 }
}
function setProfileMode(mode){
 profileMode=mode;$('annualProfilePanel').hidden=mode!=='annual';$('monthlyEntryPanel').hidden=mode!=='monthly';$('profileDialogTotalRow').hidden=mode!=='monthly';$('importStatus').hidden=mode!=='monthly';
 document.querySelectorAll('[data-profile-mode]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.profileMode===mode)));
 document.querySelectorAll('#monthInputs input').forEach(el=>el.disabled=mode==='annual');
 $('applyProfileText').textContent=mode==='annual'?'Använd uppskattad profil':'Använd förbrukning';$('applyProfile').disabled=false;
 if(mode==='annual')updateAnnualPreview();
}
function setupAnnualDraft(s){
 const period=s.period,p=s.profiles[period],e=s.sources[period]==='estimated'?s.estimates[period]:null;
 $('annualUnit').value='kwh';$('annualConsumption').value=e?fmt(e.annualKwh,2):p.every(v=>v!==null)?fmt(p.reduce((a,v)=>a+v,0),2):'';
 document.querySelectorAll('input[name="profileShape"]').forEach(el=>el.checked=el.value===(e?.shape??'winter'));
 $('annualProfileError').hidden=true;$('annualPreview').hidden=true;
}
function openProfile(){pendingImport=null;profileImported=false;$('customer').value=state.customer;fillProfile(state.profiles[state.period]);setupAnnualDraft(state);setProfileMode(state.sources[state.period]==='estimated'&&!state.estimates[state.period].adjusted?'annual':'monthly');$('profileFile').value='';$('importStatus').textContent='Tomt fält = saknas. 0 = angiven förbrukning på noll kWh.';$('importStatus').classList.remove('error');$('profileDialog').showModal();}
function updateDialogTotal(){const total=MONTHS.reduce((a,_,i)=>a+Number($('month'+i).value||0),0);$('dialogTotal').textContent=fmt(total)+' kWh';}
function download(name,content,type){const blob=new Blob([content],{type}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);}
function csvCell(value){let str=String(value);if(/^[=+\-@]/.test(str)&&!/^[-+]?\d+(?:[,.]\d+)?$/.test(str))str="'"+str;return '"'+str.replaceAll('"','""')+'"';}
function filename(){return (state.customer.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,60)||'kundrum').toLowerCase();}
for(const id of ['editCustomer','editProfile','editProfileTop'])$(id).addEventListener('click',openProfile);
document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',()=>b.closest('dialog').close()));
document.querySelectorAll('dialog').forEach(d=>d.addEventListener('click',e=>{if(e.target===d){const r=d.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)d.close();}}));
document.querySelectorAll('[data-period]').forEach(b=>b.addEventListener('click',()=>{state.period=b.dataset.period;save();render();}));
document.querySelectorAll('[data-chart-unit]').forEach(b=>b.addEventListener('click',()=>{chartUnit=b.dataset.chartUnit;renderCharts(calculate(state));}));
$('monthButtons').addEventListener('click',e=>{const button=e.target.closest('[data-month-index]');if(button)selectMonth(Number(button.dataset.monthIndex),true);});
$('costChart').addEventListener('click',e=>{const target=e.target.closest('[data-chart-month]');if(target)selectMonth(Number(target.dataset.chartMonth),true);});
$('monthButtons').addEventListener('keydown',e=>{
 if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;
 const buttons=[...$('monthButtons').querySelectorAll('button:not(:disabled)')],current=buttons.indexOf(e.target);
 if(current<0)return;e.preventDefault();
 const next=e.key==='Home'?0:e.key==='End'?buttons.length-1:(current+(e.key==='ArrowRight'?1:-1)+buttons.length)%buttons.length;
 const index=Number(buttons[next].dataset.monthIndex);selectMonth(index);$('monthButtons').querySelector(`[data-month-index="${index}"]`).focus({preventScroll:true});
});
for(const k of ['consumption','hedge','fixed','portfolioFee','variableFee']){$(k).addEventListener('input',()=>{const el=$(k),n=Number(el.value);if(el.value===''||!el.validity.valid||!Number.isFinite(n)){el.classList.add('error-field');return;}el.classList.remove('error-field');state[k]=n;save();render();});$(k).addEventListener('blur',()=>{$(k).value=state[k];$(k).classList.remove('error-field');});}
for(const k of ['notes','next','date','choice'])$(k).addEventListener('input',()=>{state[k]=$(k).value;save();});
$('businessType').addEventListener('change',()=>{state.business={type:$('businessType').value,apartments:null};$('businessApartments').value='';$('businessApartments').removeAttribute('aria-invalid');$('businessApartmentError').hidden=true;save();render();});
$('businessApartments').addEventListener('input',()=>{const raw=$('businessApartments').value.trim(),n=Number(raw),valid=raw===''||/^\d+$/.test(raw)&&Number.isInteger(n)&&n>=1&&n<=100000;state.business={type:$('businessType').value,apartments:valid&&raw!==''?n:null};$('businessApartmentError').hidden=valid;$('businessApartments').setAttribute('aria-invalid',String(!valid));save();render();});
$('resetScenario').addEventListener('click',()=>{for(const k of ['consumption','hedge','fixed','portfolioFee','variableFee'])state[k]=defaults()[k];setControls();save();render();toast('Reglagen återställda till 80 % säkring och filens påslag.');});
$('monthInputs').addEventListener('input',updateDialogTotal);
document.querySelectorAll('[data-profile-mode]').forEach(b=>b.addEventListener('click',()=>setProfileMode(b.dataset.profileMode)));
$('annualConsumption').addEventListener('input',updateAnnualPreview);$('annualUnit').addEventListener('change',updateAnnualPreview);
document.querySelectorAll('input[name="profileShape"]').forEach(el=>el.addEventListener('change',updateAnnualPreview));
$('profileForm').addEventListener('submit',e=>{e.preventDefault();const customer=$('customer').value.trim(),target=pendingImport?cleanState(pendingImport):cleanState(state),period=target.period;target.estimates??={};let profile;
 if(profileMode==='annual'){
  if(!updateAnnualPreview())return;const draft=readAnnualDraft();profile=draft.profile;target.sources[period]='estimated';target.estimates[period]=draft.estimate;
 }else{
  profile=MONTHS.map((_,i)=>$('month'+i).value===''?null:Number($('month'+i).value));
  const changed=!profile.every((v,i)=>v===target.profiles[period][i]);
  if(profileImported){target.sources[period]='own';delete target.estimates[period];}
  else if(changed){if(target.sources[period]==='estimated')target.estimates[period].adjusted=true;else target.sources[period]='own';}
 }
 target.profiles[period]=profile;target.customer=customer;
 if(!validateState(target)){ $('importStatus').textContent='Kontrollera företagsnamn och månadsvärden.';$('importStatus').classList.add('error');return;}
 state=target;setControls();save();render();$('profileDialog').close();toast(canSave?'Kundrummet är uppdaterat.':'Uppdaterat. Exportera för att behålla uppgifterna.');});
$('profileFile').addEventListener('change',async e=>{const f=e.target.files?.[0];if(!f)return;try{if(f.size>1024*1024)throw Error('Maximal filstorlek är 1 MB.');const txt=await f.text();let p;
 if(f.name.toLowerCase().endsWith('.json')){const data=JSON.parse(txt),s=data.version===1?migrateLegacy(data.state):data.version===2?data.state:null;if(!validateState(s))throw Error('Filen är inte ett giltigt kundrum med detta prisunderlag.');pendingImport=cleanState(s);p=s.profiles[s.period];$('customer').value=s.customer;profileImported=false;}else{p=parseProfile(txt);pendingImport=null;profileImported=true;}
 fillProfile(p);setupAnnualDraft(pendingImport??{...state,profiles:{...state.profiles,[state.period]:p},sources:{...state.sources,[state.period]:'own'}});setProfileMode('monthly');$('importStatus').classList.remove('error');$('importStatus').textContent=pendingImport?'Kundrummet inläst. Använd förbrukning återställer även år, reglage och anteckningar.':'Profilen är inläst för valt år. Tomma månader ingår inte i jämförelsen.';
 }catch(err){$('importStatus').textContent='Kunde inte läsa filen: '+err.message;$('importStatus').classList.add('error');}finally{e.target.value='';}});
$('downloadTemplate').addEventListener('click',()=>download('manadsprofil-mall.csv','\uFEFFMånad;kWh\n'+MONTHS.map(m=>m+';').join('\n'),'text/csv;charset=utf-8'));
$('sellerName').addEventListener('change',()=>{const name=$('sellerName').value.trim();if(!name||/[\r\n]/.test(name)){toast('Ange säljarens namn.');return;}state.sellerName=name;save();render();});
function shareEmail(){return buildCustomerEmail(shareSnapshot,{recipientName:$('shareCustomerName').value,recipientEmail:$('shareCustomerEmail').value.trim(),includeNotes:$('shareIncludeNotes').checked});}
function updateEmailPreview(){
 try{const email=shareEmail();$('emailPreview').innerHTML=email.body;$('shareSubject').textContent=email.subject;$('shareYear').textContent=shareSnapshot.period;$('shareNotesLabel').textContent=shareSnapshot.notes.trim()?`Ta med ${sellerNotesTitle(shareSnapshot.sellerName)}`:'Inga anteckningar är ifyllda';$('shareIncludeNotes').disabled=!shareSnapshot.notes.trim();$('shareStatus').textContent='';}catch(err){$('shareStatus').textContent=err.message;}
}
function openShare(){
 if(!calculate(state).volume){toast('Lägg in förbrukning med prisunderlag innan du delar.');return;}
 shareSnapshot=cleanState(state);shareSnapshot.sellerName??='Ludwig Rosenberg';
 $('shareCustomerName').value='';$('shareCustomerEmail').value='';$('shareCustomerEmail').setCustomValidity('');$('shareSellerName').value=shareSnapshot.sellerName;$('shareSellerName').setCustomValidity('');$('shareIncludeNotes').checked=!!shareSnapshot.notes.trim();
 updateEmailPreview();$('shareDialog').showModal();
}
for(const id of ['shareTop','shareBottom'])$(id).addEventListener('click',openShare);
for(const id of ['shareCustomerName','shareIncludeNotes'])$(id).addEventListener('input',updateEmailPreview);
$('shareCustomerEmail').addEventListener('input',()=>{$('shareCustomerEmail').setCustomValidity('');$('shareStatus').textContent='';});
$('shareSellerName').addEventListener('input',()=>{const name=$('shareSellerName').value.trim();$('shareSellerName').setCustomValidity(name&&!/[\r\n]/.test(name)?'':'Ange säljarens namn.');if(name&&!/[\r\n]/.test(name)){shareSnapshot.sellerName=name;state.sellerName=name;$('sellerName').value=name;save();render();updateEmailPreview();}});
async function copyEmail(email){
 if(navigator.clipboard?.write&&typeof ClipboardItem!=='undefined'){
  try{await navigator.clipboard.write([new ClipboardItem({'text/html':new Blob([email.body],{type:'text/html'}),'text/plain':new Blob([email.text],{type:'text/plain'})})]);return;}catch{}
 }
 if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(email.text);return;}
 throw Error('Kopiering stöds inte här. Hämta mejlfilen i stället.');
}
function recipientValid(){const el=$('shareCustomerEmail');el.setCustomValidity(validEmail(el.value.trim())?'':'Ange en giltig mejladress för en kund.');return $('shareForm').reportValidity();}
$('copyCustomerEmail').addEventListener('click',async()=>{if(!$('shareSellerName').reportValidity())return;try{await copyEmail(shareEmail());$('shareStatus').textContent='Hela mejlet är kopierat. Klistra in det i ditt mejlprogram. Inget har skickats.';}catch{$('shareStatus').textContent='Kunde inte kopiera. Hämta mejlfilen i stället.';}});
$('downloadCustomerEmail').addEventListener('click',()=>{if(!recipientValid())return;try{const email=shareEmail();download(filename()+'-'+shareSnapshot.period+'-kundmejl.eml',emailFile(email),'application/octet-stream');$('shareStatus').textContent='Mejlfilen är skapad och nedladdningen har startats. Öppna filen i ditt mejlprogram och kontrollera avsändare och mottagare. Inget har skickats.';}catch{$('shareStatus').textContent='Kunde inte skapa mejlfilen. Kopiera mejlet i stället.';}});
$('shareForm').addEventListener('submit',async e=>{e.preventDefault();if(!recipientValid())return;const button=$('openCustomerEmail');button.disabled=true;try{const email=shareEmail();await copyEmail(email);const link=document.createElement('a');link.href=mailtoLink({...email,text:''});document.body.append(link);link.click();link.remove();$('shareStatus').textContent='Mejlet är kopierat. Klistra in (Ctrl+V eller ⌘V) i mejlet som öppnas och klicka Skicka där. Om inget öppnas: skapa ett mejl själv och klistra in. Inget har skickats från kundrummet.';}catch{$('shareStatus').textContent='Kunde inte kopiera. Hämta mejlfilen eller kopiera förhandsvisningen manuellt. Inget har skickats.';}finally{button.disabled=false;}});
for(const k of ['exportTop','exportBottom'])$(k).addEventListener('click',()=>$('exportDialog').showModal());
$('downloadRoom').addEventListener('click',()=>{download(filename()+'-kundrum.json',JSON.stringify({version:2,exportedAt:new Date().toISOString(),state},null,2),'application/json');toast('Redigerbart kundrum exporterat.');});
$('downloadCalculation').addEventListener('click',()=>{
 const r=calculate(state),n=v=>v===null?'':v.toFixed(2).replace('.',','),keys=['volume','hedged','spot','running','weighting','cost','variableRate','portfolioRate','differenceRate','variable','portfolio','difference','fixedRate','fixed'];
 const rows=[['Kundrummet – beräknad jämförelse, ingen offert'],['Företag',state.customer],['År',r.periodLabel],['Källa',DATA.sourceName],['Prisunderlag ID',DATA.id],['Profilkälla',profileSourceLabel(state)],['Verksamhet',businessImpact(r,state).type.label],['Antal lägenheter',state.business?.type==='brf'?state.business.apartments??'':''],['Skillnad per lägenhet kr (plus = besparing)',state.business?.type==='brf'&&state.business.apartments?n(r.difference/state.business.apartments):''],...businessImpact(r,state).lines.map(line=>[line]),['Förbrukning av profil (%)',state.consumption],['Säkringsgrad (%)',state.hedge],['Säkringsgraden gäller volym, inte hela fakturan. Förbrukningsprofil och andra kostnader påverkar fortfarande slutpriset.'],['Påslag portfölj öre/kWh',n(state.portfolioFee)],['Påslag rörligt öre/kWh',n(state.variableFee)],['Fastpris öre/kWh',n(state.fixed)],['Kostnadstillägg = rörlig kostnad minus volymvägning, gäller portfölj och rörligt. Inget separat säkringspåslag.'],['Portfölj = kWh × (säkrad andel × säkrat pris + rörlig andel × rörligt pris + kostnadstillägg + portföljpåslag) / 100.'],['Rörligt = kWh × (rörligt pris + kostnadstillägg + rörligt påslag) / 100. Fastpris = kWh × fastpris / 100.'],['Belopp exklusive moms, elnät och energiskatt. Månadsmodell. Ingen fakturaberäkning.'],['Skillnad = rörligt minus portfölj. Positivt = besparing; negativt = merkostnad. Snittpriser viktas efter förbrukning. Skillnader räknas före avrundning.'],[],['Sammanfattning','Snittpris öre/kWh','Kostnad kr'],['Rörligt',n(r.variableRate),n(r.variable)],['Portfölj',n(r.portfolioRate),n(r.portfolio)],['Skillnad',n(r.differenceRate),n(r.difference)],['Fastpris',n(r.fixedRate),n(r.fixed)],[],['Månad','kWh','Säkrat öre/kWh','Rörligt baspris öre/kWh','Rörlig kostnad öre/kWh','Volymvägning öre/kWh','Kostnadstillägg öre/kWh','Rörligt inkl tillägg öre/kWh','Portfölj inkl tillägg öre/kWh','Skillnad öre/kWh','Rörligt kr','Portfölj kr','Skillnad kr','Fastpris öre/kWh','Fastpris kr','Status'],...r.rows.map(row=>[row.month,...keys.map(k=>n(row.available?row[k]:k==='volume'?row.volume:null)),row.available?'Ingår':'Underlag saknas – ingår inte']),['Totalt / vägt snitt',...keys.map(k=>n(r[k]??null)),`${r.count} månader`]];
 download(filename()+'-'+state.period+'-berakning.csv','\uFEFF'+rows.map(row=>row.map(csvCell).join(';')).join('\r\n'),'text/csv;charset=utf-8');
});
function prepareReport(){
 const r=calculate(state),choice={undecided:'Vi vill jämföra mer',variable:'Rörligt',portfolio:'Portfölj',fixed:'Fastpris'}[state.choice];
 $('printArea').innerHTML=`<div class="print-brand"><img src="/brand/kraftringen-logo.svg" alt="Kraftringen" width="190" height="33"><span>Kundrummet</span></div><p>KUNDRUMMET · ${new Date().toLocaleDateString('sv-SE')}</p><h1>${esc(state.customer)}</h1><p class="print-note"><strong>Beräknad jämförelse – ingen offert.</strong> Månadsmodell med priser från ditt Excelunderlag och valbar säkringsgrad.</p><h2>${r.periodLabel}</h2><p>${r.count} månader med underlag. Förbrukning i jämförelsen: ${fmt(r.volume)} kWh (${state.consumption} % av profilen).<br>Profil: ${esc(profileSourceLabel(state))} Säkringsgrad: ${state.hedge} %.<br>Påslag portfölj: ${fmt(state.portfolioFee,2)} öre/kWh. Påslag rörligt: ${fmt(state.variableFee,2)} öre/kWh. Fastpris: ${fmt(state.fixed,2)} öre/kWh.</p><table class="print-comparison"><thead><tr><th>Alternativ</th><th>Snittpris, öre/kWh</th><th>Kostnad för perioden, kr</th></tr></thead><tbody><tr><td>Rörligt</td><td>${fmt(r.variableRate,2)}</td><td>${fmt(r.variable,2)}</td></tr><tr><td>Portfölj</td><td>${fmt(r.portfolioRate,2)}</td><td>${fmt(r.portfolio,2)}</td></tr><tr><td>Fastpris</td><td>${fmt(r.fixedRate,2)}</td><td>${fmt(r.fixed,2)}</td></tr></tbody></table><div class="print-savings"><strong>${savingsTitle(r)}</strong><p>${savingsValue(r.differenceRate)} öre/kWh · ${savingsValue(r.volume?r.difference:null)} kr för perioden</p></div><p>Förbrukningsvägda snittpriser. Belopp exklusive moms, elnät och energiskatt.</p><h2>För er verksamhet</h2>${businessImpact(r,state).lines.map(line=>`<p>${esc(line)}</p>`).join('')}<h2>Priser per månad · öre/kWh</h2><div class="print-chart">${priceChart(r,'ore','print-price')}</div><p>Korall: rörligt. Blå: portfölj. Streckad grå: fastpris.</p><h2>Besparing eller merkostnad per månad · kr</h2><div class="print-chart">${differenceChart(r,'kr','print-difference')}</div><p>Plus = besparing med portfölj. Minus = merkostnad.</p><h2>Månadstabell</h2><table class="print-months"><thead><tr><th>Månad</th><th>kWh</th><th>Rörligt<br>öre/kWh</th><th>Portfölj<br>öre/kWh</th><th>Skillnad<br>öre/kWh</th><th>Rörligt<br>kr</th><th>Portfölj<br>kr</th><th>Skillnad<br>kr</th><th>Fastpris<br>kr</th></tr></thead><tbody>${tableRows(r)}</tbody><tfoot>${totalRow(r)}</tfoot></table><h2>${esc(sellerNotesTitle(state.sellerName||'Ludwig Rosenberg'))}</h2><p class="print-notes">${esc(state.notes||'Inga anteckningar ännu.')}</p><p><strong>Alternativ att undersöka:</strong> ${choice}<br><strong>Nästa steg:</strong> ${esc(state.next||'Inte bestämt')}<br><strong>Uppföljningsdatum:</strong> ${esc(state.date||'Inte bestämt')}</p><h2>Beräkning och underlag</h2>${$('methodText').innerHTML}<p class="source-filename">${esc($('sourceFile').textContent)}</p><p>Kontakt: ${esc(state.sellerName||'Ludwig Rosenberg')}. Valet är en mötesanteckning. Inget avtal eller någon bokning skapas.</p>`;
}
window.addEventListener('beforeprint',prepareReport);
$('printReport').addEventListener('click',()=>{$('exportDialog').close();prepareReport();window.print();});
$('resetRoom').addEventListener('click',()=>$('resetDialog').showModal());$('confirmReset').addEventListener('click',()=>{state=defaults();migrated=false;$('migrationNote').hidden=true;setControls();save();render();$('resetDialog').close();toast('Filens värden och 80 % säkring har återställts.');});
document.querySelectorAll('.header nav a').forEach(a=>a.addEventListener('click',()=>{document.querySelectorAll('.header nav a').forEach(x=>x.classList.remove('active'));a.classList.add('active');}));
if(migrated){$('migrationNote').hidden=false;$('migrationNote').textContent='Din tidigare profil och dina anteckningar finns kvar. Demopriserna har ersatts med Excelunderlaget och dess påslag. Profilen har kopierats till båda åren.';save();}
initMobile();setControls();render();
