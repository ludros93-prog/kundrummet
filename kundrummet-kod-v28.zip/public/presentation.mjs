import {STORY_CATALOG,STORY_SOURCE_NOTE} from './meeting-stories.mjs';
const story=STORY_CATALOG[new URLSearchParams(location.search).get('deck')],root=document.getElementById('reference');
root.replaceChildren();
function add(tag,content,cls){const el=document.createElement(tag);el.textContent=content;if(cls)el.className=cls;root.append(el);}
if(story){document.title=story.title+' · Kraftringen Kundrummet';add('p',story.sector,'eyebrow');add('h1',story.title);add('blockquote','”'+story.quote+'”');add('p',story.person,'quote-person');add('p','Källa: '+story.source,'reference-source');add('p',STORY_SOURCE_NOTE,'reference-source');}else{add('h1','Välj en kundröst');add('p','Den här kundrösten finns inte i det aktuella urvalet. Du hittar alla kundröster på översiktssidan.');}
const button=document.getElementById('fullscreen');if(root.requestFullscreen){button.hidden=false;button.addEventListener('click',async()=>{try{await root.requestFullscreen();}catch{button.textContent='Helskärm stöds inte här';}});}
