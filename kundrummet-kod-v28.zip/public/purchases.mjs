// Teaching model: cadence and 24-to-4-month window supplied by Ludwig.
// Equal daily sizes, 80% target, example dates and extra holiday-eve closures are illustrative.
const DAY=86400000;
const date=(y,m,d)=>new Date(Date.UTC(y,m-1,d));
const key=d=>d.toISOString().slice(0,10);
const addDays=(d,n)=>new Date(d.getTime()+n*DAY);
const fmtDate=new Intl.DateTimeFormat('sv-SE',{day:'numeric',month:'long',year:'numeric',timeZone:'UTC'});
const fmtShort=new Intl.DateTimeFormat('sv-SE',{day:'numeric',month:'short',year:'numeric',timeZone:'UTC'});
const fmtWeekday=new Intl.DateTimeFormat('sv-SE',{weekday:'long',timeZone:'UTC'});
const pct=n=>new Intl.NumberFormat('sv-SE',{maximumFractionDigits:1}).format(n);
const precise=n=>new Intl.NumberFormat('sv-SE',{maximumFractionDigits:2}).format(n);
const holidayCache=new Map();
function easter(year){
 const a=year%19,b=Math.floor(year/100),c=year%100,d=Math.floor(b/4),e=b%4,f=Math.floor((b+8)/25),g=Math.floor((b-f+1)/3);
 const h=(19*a+b-d-g+15)%30,i=Math.floor(c/4),k=c%4,l=(32+2*e+2*i-h-k)%7,m=Math.floor((a+11*h+22*l)/451);
 const n=h+l-7*m+114;return date(year,Math.floor(n/31),n%31+1);
}
function saturdayFrom(d){return addDays(d,(6-d.getUTCDay()+7)%7);}
// Swedish public holidays: SFS 1989:253. Eves are additional example closures, not public holidays.
export function holidayName(day){
 const year=day.getUTCFullYear();
 if(!holidayCache.has(year)){
  const days=new Map(),put=(d,name)=>days.set(key(d),name),e=easter(year),midsummer=saturdayFrom(date(year,6,20));
  for(const [m,d,name] of [[1,1,'Nyårsdagen'],[1,6,'Trettondedag jul'],[5,1,'Första maj'],[6,6,'Nationaldagen'],[12,25,'Juldagen'],[12,26,'Annandag jul']])put(date(year,m,d),name);
  for(const [offset,name] of [[-2,'Långfredagen'],[0,'Påskdagen'],[1,'Annandag påsk'],[39,'Kristi himmelsfärdsdag'],[49,'Pingstdagen']])put(addDays(e,offset),name);
  put(midsummer,'Midsommardagen');put(saturdayFrom(date(year,10,31)),'Alla helgons dag');
  put(addDays(midsummer,-1),'Midsommarafton');put(date(year,12,24),'Julafton');put(date(year,12,31),'Nyårsafton');
  holidayCache.set(year,days);
 }
 return holidayCache.get(year).get(key(day))||null;
}
export function dayClosure(day){return holidayName(day)||([0,6].includes(day.getUTCDay())?'Helg':null);}
export function buildPurchaseSchedule(deliveryYear=2028){
 if(!Number.isInteger(deliveryYear)||deliveryYear<2007||deliveryYear>2100)throw new RangeError('Ogiltigt leveransår');
 const start=date(deliveryYear-2,1,1),finish=date(deliveryYear-1,9,1),delivery=date(deliveryYear,1,1),target=80,days=[];
 let purchases=0;
 for(let day=start;day<=delivery;day=addDays(day,1)){
  const closure=dayClosure(day),phase=day>=delivery?'delivery':day>=finish?'complete':'buying',buy=phase==='buying'&&!closure;
  if(buy)purchases++;
  days.push({index:days.length,iso:key(day),date:day,closure,phase,buy,purchases,fullDate:fmtDate.format(day),shortDate:fmtShort.format(day),weekday:fmtWeekday.format(day)});
 }
 const totalPurchases=purchases,dailyShare=target/totalPurchases;
 const rows=days.map(d=>Object.freeze({...d,secured:target*d.purchases/totalPurchases,market:100-target*d.purchases/totalPurchases,added:d.buy?dailyShare:0}));
 const positions=[start,date(deliveryYear-2,7,1),date(deliveryYear-1,1,1),finish,delivery];
 const labels=['24 mån före','18 mån före','12 mån före','4 mån före','Leverans'];
 const marks=positions.map((d,i)=>Object.freeze({index:(d-start)/DAY,label:labels[i],date:fmtShort.format(d)}));
 return Object.freeze({days:Object.freeze(rows),marks:Object.freeze(marks),totalPurchases,dailyShare,target,deliveryYear,start:key(start),finish:key(finish),delivery:key(delivery)});
}
export function purchaseSnapshot(index,schedule){
 if(!Number.isInteger(index)||index<0||index>=schedule.days.length)throw new RangeError('Ogiltig dag');
 return schedule.days[index];
}
export function initPurchases(){
 const $=id=>document.getElementById(id),dialog=$('purchasesDialog'),slider=$('purchaseTimeline'),schedule=buildPurchaseSchedule(),last=schedule.days.length-1;
 const marks=[...dialog.querySelectorAll('[data-purchase-step]')],blocks=[...dialog.querySelectorAll('.purchase-block')],weekButtons=[...dialog.querySelectorAll('[data-purchase-day]')];
 let index=0,timer=null,opener=null;
 slider.max=last;
 marks.forEach((button,i)=>{const m=schedule.marks[i];button.dataset.purchaseStep=m.index;button.querySelector('b').textContent=m.label;button.querySelector('small').textContent=i===3?'Klar':i===4?'Start':'Bygger upp';button.setAttribute('aria-label',`${m.label}, ${m.date}${i===3?', uppbyggnaden klar':''}`);});
 $('purchasePeriod').textContent=`Exempel: prissäkringar ${schedule.deliveryYear-2}–${schedule.deliveryYear-1} · leveransstart 1 jan ${schedule.deliveryYear}`;
 function announce(){const s=schedule.days[index];$('purchaseStatus').textContent=`${s.fullDate}. ${pct(s.secured)} procent säkrad volym. ${pct(s.market)} procent osäkrad volym. ${s.buy?'Ny prissäkring':s.phase==='buying'?(s.closure+', ingen ny säkring'):'Uppbyggnaden är klar'}.`;}
 function stop(){clearInterval(timer);timer=null;$('purchasePlay').textContent=index===last?'Spela igen':'Spela upp';$('purchasePlay').setAttribute('aria-pressed','false');announce();}
 function render(speak=true){
  const s=purchaseSnapshot(index,schedule),complete=s.phase!=='buying',selectedMark=schedule.marks.findLastIndex(m=>m.index<=index);
  slider.value=index;slider.setAttribute('aria-valuetext',`${s.fullDate}: ${pct(s.secured)} procent säkrad volym, ${pct(s.market)} procent osäkrad volym`);slider.style.setProperty('--purchase-progress',index/last*100+'%');
  $('purchaseTime').textContent=s.shortDate;$('purchasePercent').textContent=pct(s.secured)+' %';$('purchaseMarket').textContent=pct(s.market)+' %';$('purchaseCount').textContent=`${s.purchases} av ${schedule.totalPurchases} dagar med ny säkring`;
  $('purchaseDayStatus').textContent=complete?'Uppbyggnaden klar':s.buy?'Ny prissäkring':s.closure+' · ingen ny säkring';
  $('purchaseDayAmount').textContent=complete?'Inga fler säkringar i exemplet':s.buy?`+ ≈ ${precise(s.added)} procentenheter`:'Säkringen ligger kvar';
  $('purchaseDayStatus').dataset.buy=String(s.buy);
  const title=s.phase==='delivery'?'Nu börjar ni använda elen.':complete?'Klar fyra månader före leverans.':index===0?'Två år före leverans börjar vi.':!s.buy?'Paus idag. Prisavtalen ligger kvar.':`${pct(s.secured)} % av den planerade mängden är säkrad.`;
  const text=s.phase==='delivery'?`Prisavtalen motsvarar 80 % av den planerade mängden el. De blev klara fyra månader tidigare. Er förbrukning och andra kostnader påverkar fortfarande slutpriset.`:complete?`Vi har nått målet: prisavtal för 80 % av den planerade mängden. De sista 20 % saknar prissäkring. Under de sista fyra månaderna lägger vi inte till fler säkringar i exemplet.`:index===0?'Vi gör små prisavtal på handelsdagar, från två år till fyra månader före leverans. Idag är det nyårsdagen, så den första säkringen görs nästa handelsdag.':!s.buy?`${s.closure}: ingen ny säkring idag. Prisavtalen täcker fortfarande ${pct(s.secured)} % av den planerade mängden. Vi fortsätter nästa handelsdag, tills uppbyggnaden är klar.`:`Prisavtalen har byggts på under ${s.purchases} handelsdagar. Nu är ${pct(s.secured)} % av den planerade mängden prissäkrad och ${pct(s.market)} % osäkrad. En andel på exempelvis 60 % kan betyda att vi fortfarande bygger upp mot målet 80 %.`;
  $('purchaseStageTitle').textContent=title;$('purchaseStageText').textContent=text;$('purchaseEvent').textContent=s.phase==='delivery'?'Leveransstart':complete?'Säkringarna är färdiga':`Dag för dag · ${s.weekday} ${s.shortDate}`;
  blocks.forEach((b,i)=>{const fill=Math.max(0,Math.min(100,(s.secured-i*10)*10));b.style.setProperty('--block-fill',fill+'%');b.dataset.full=String(fill>=100);});
  marks.forEach((b,i)=>{b.setAttribute('aria-pressed',String(i===selectedMark));b.dataset.passed=String(Number(b.dataset.purchaseStep)<=index);});
  const monday=index-(s.date.getUTCDay()+6)%7;
  weekButtons.forEach((button,i)=>{
   const pos=monday+i,d=schedule.days[pos];button.disabled=!d;button.dataset.purchaseDay=pos;button.setAttribute('aria-pressed',String(pos===index));
   const outDate=d?.date||addDays(s.date,pos-index);
   button.querySelector('b').textContent=outDate.getUTCDate();button.querySelector('span').textContent=!d?'':d.buy?'•':'–';
   button.dataset.buy=String(!!d?.buy);button.dataset.passed=String(pos<=index);
   button.setAttribute('aria-label',`${fmtDate.format(outDate)}: ${!d?'utanför exemplet':d.phase!=='buying'?'uppbyggnaden klar':d.buy?'handelsdag':d.closure+', ingen ny säkring'}`);
  });
  $('purchasePrevious').disabled=index===0;$('purchaseNext').disabled=index===last;
  if(!timer)$('purchasePlay').textContent=index===last?'Spela igen':'Spela upp';if(speak)announce();
 }
 function go(next){stop();index=next;render();}
 const tabs=[...dialog.querySelectorAll('[data-portfolio-tab]')];
 function selectTab(name,focus=false){
  stop();
  for(const button of tabs){const active=button.dataset.portfolioTab===name;button.setAttribute('aria-selected',String(active));button.tabIndex=active?0:-1;$(button.getAttribute('aria-controls')).hidden=!active;if(active&&focus)button.focus({preventScroll:true});}
  dialog.scrollTop=0;
 }
 tabs.forEach((button,i)=>{
  button.addEventListener('click',()=>selectTab(button.dataset.portfolioTab));
  button.addEventListener('keydown',event=>{
   let next;if(event.key==='ArrowRight')next=(i+1)%tabs.length;else if(event.key==='ArrowLeft')next=(i-1+tabs.length)%tabs.length;else if(event.key==='Home')next=0;else if(event.key==='End')next=tabs.length-1;else return;
   event.preventDefault();selectTab(tabs[next].dataset.portfolioTab,true);
  });
 });
 $('portfolioShowTimeline').addEventListener('click',()=>selectTab('timeline',true));
 const priceButtons=[...dialog.querySelectorAll('[data-price-example]')];
 function priceExample(which){
  const spot=which==='low'?40:100,agreed=70,adjustment=agreed-spot;
  $('portfolioSpot').textContent=spot+' öre';$('portfolioAdjustmentLabel').textContent=adjustment<0?'Prisavtalet ger tillbaka':'Prisavtalet lägger till';
  $('portfolioAdjustment').textContent=(adjustment<0?'−':'+')+Math.abs(adjustment)+' öre';$('portfolioNet').textContent=(spot+adjustment)+' öre';
  priceButtons.forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.priceExample===which)));
 }
 priceButtons.forEach(button=>button.addEventListener('click',()=>priceExample(button.dataset.priceExample)));
 document.querySelectorAll('[data-open-purchases]').forEach(button=>button.addEventListener('click',()=>{opener=button;go(0);selectTab('simple');priceExample('high');dialog.showModal();dialog.scrollTop=0;}));
 slider.addEventListener('input',()=>go(Number(slider.value)));
 marks.forEach(b=>b.addEventListener('click',()=>go(Number(b.dataset.purchaseStep))));
 weekButtons.forEach(b=>b.addEventListener('click',()=>go(Number(b.dataset.purchaseDay))));
 $('purchasePrevious').addEventListener('click',()=>go(Math.max(0,index-1)));$('purchaseNext').addEventListener('click',()=>go(Math.min(last,index+1)));
 $('purchasePlay').addEventListener('click',()=>{
  if(timer){stop();return;}if(index===last)index=0;
  $('purchasePlay').textContent='Pausa';$('purchasePlay').setAttribute('aria-pressed','true');
  timer=setInterval(()=>{index=Math.min(last,index+1);render(false);if(index===last)stop();},50);render(false);
 });
 dialog.addEventListener('close',()=>{stop();opener?.focus({preventScroll:true});});document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();});render();
}
