import {businessImpact} from './business-impact.mjs';
import {calculate,profileSourceLabel,validateState} from './model.mjs';
const fmt=(n,d=2)=>new Intl.NumberFormat('sv-SE',{minimumFractionDigits:d,maximumFractionDigits:d}).format(n);
export const escapeHtml=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const sellerNotesTitle=name=>`${name.trim()}${/[sxz]$/i.test(name.trim())?'':'s'} anteckningar`;
export const validEmail=s=>typeof s==='string'&&s.length<=254&&!/[\u0000-\u001f\u007f]/.test(s)&&/^[^\s@<>,;:"\\]+@[^\s@<>,;:"\\]+\.[^\s@<>,;:"\\]+$/.test(s);
const sign=n=>(Math.abs(n)<1e-8?'':n>0?'+':'−')+fmt(Math.abs(n));
const amount=n=>Math.abs(n)>1e-8&&Math.abs(n)<.005?'< 0,01':fmt(Math.abs(n));
export function buildCustomerEmail(state,{recipientName='',recipientEmail='',includeNotes=true}={}){
 if(!validateState(state))throw Error('Kundrummets underlag är inte giltigt.');
 const seller=(state.sellerName||'Ludwig Rosenberg').trim(),r=calculate(state);
 if(!seller||seller.length>100)throw Error('Ange säljarens namn.');
 if(r.volume<=0)throw Error('Lägg in förbrukning med komplett prisunderlag innan du delar.');
 const subject=`Er eljämförelse ${r.periodLabel} – ${state.customer}`.replace(/[\r\n]+/g,' ');
 const greeting=recipientName.trim()?`Hej ${recipientName.trim()}!`:'Hej!';
 const intro=`Tack för samtalet. Här är sammanställningen för ${state.customer}, utifrån de val vi gick igenom i kundrummet.`;
 const coverage=`${r.periodLabel} · ${r.count} av 12 månader · ${fmt(r.volume,r.volume%1?2:0)} kWh (${fmt(r.volume/1000)} MWh) i jämförelsen.`;
 const profile=profileSourceLabel(state).replace('ditt Excelunderlag','jämförelseunderlaget').replace('Din inlagda','Inlagd');
 const comparison=[['Rörligt',r.variableRate,r.variable],['Portfölj',r.portfolioRate,r.portfolio],['Fastpris (referens)',r.fixedRate,r.fixed]];
 const same=Math.abs(r.differenceRate)<1e-8,extra=r.difference<0;
 const resultTitle=same?'Samma beräknade kostnad':extra?'Merkostnad med portfölj':'Besparing med portfölj';
 const resultText=`${amount(r.difference)} kr · ${amount(r.differenceRate)} öre/kWh${same?'':extra?' högre kostnad än rörligt':' lägre kostnad än rörligt'}.`;
 const explanation=[
 `Med rörligt följer hela förbrukningen underlagets rörliga månadspris.`,
 `Med portfölj räknar vi här med prisavtal för ${fmt(state.hedge,0)} % av volymen och ${fmt(100-state.hedge,0)} % osäkrad volym. Procentsiffrorna gäller mängden el, inte hur stor del av hela fakturan som är låst.`,
 `Prisavtalen räknas av i pengar och justerar elkostnaden uppåt eller nedåt. När och hur mycket el ni använder, avgifter, balanskostnader, elcertifikat och ursprungsgarantier kan fortfarande påverka slutpriset. Den här månadsjämförelsen beräknar inte er egen förbrukningsprofil från kvartsmätvärden.`,
 `Månadskostnaden är förbrukningen i kWh × priset i öre/kWh ÷ 100. Snittpriset vägs efter hur mycket el som används varje månad. Samma förbrukning används för alla alternativ.`,
 `Påslag: portfölj ${fmt(state.portfolioFee)} öre/kWh och rörligt ${fmt(state.variableFee)} öre/kWh. Underlagets kostnadstillägg ingår i båda. Inget separat säkringspåslag har lagts till. Fastprisreferensen är ${fmt(state.fixed)} öre/kWh.`,
 `Förbrukningen är beräknad med ${fmt(state.consumption,0)} % av den inlagda profilen. ${profile}`,
 ...(r.count<12?[`Månader utan komplett pris- eller förbrukningsunderlag ingår inte i jämförelsen: ${r.rows.filter(row=>!row.available).map(row=>row.month).join(', ')}.`]:[]),
 `Beloppen är exklusive moms, elnät och energiskatt. Detta är en beräknad jämförelse med månadspriser, inte en faktura, offert eller garanti för framtida besparing.`
 ];
 const impact=businessImpact(r,state);
 const notes=includeNotes&&state.notes.trim()?state.notes.trim():'';
 const choice={variable:'Rörligt',portfolio:'Portfölj',fixed:'Fastpris'}[state.choice];
 const followup=[...(choice?[`Alternativ att undersöka vidare: ${choice}.`]:[]),...(state.next.trim()?[`Nästa steg: ${state.next.trim()}`]:[]),...(state.date?[`Uppföljningsdatum: ${state.date}`]:[])];
 const monthly=r.rows.filter(row=>row.available).map(row=>`${row.month} · ${fmt(row.volume,row.volume%1?2:0)} kWh\nRörligt: ${fmt(row.variableRate)} öre/kWh / ${fmt(row.variable)} kr. Portfölj: ${fmt(row.portfolioRate)} öre/kWh / ${fmt(row.portfolio)} kr. Skillnad: ${sign(row.differenceRate)} öre/kWh / ${sign(row.difference)} kr.`);
 const text=[greeting,intro,coverage,'JÄMFÖRELSE',...comparison.map(([name,rate,cost])=>`${name}: ${fmt(rate)} öre/kWh · ${fmt(cost)} kr.`),`${resultTitle}\n${resultText}`,'FÖR ER VERKSAMHET',...impact.lines,'SÅ FUNGERAR JÄMFÖRELSEN',...explanation,...(notes?[sellerNotesTitle(seller),notes]:[]),...(followup.length?['DET HÄR TAR VI VIDARE',...followup]:[]),'MÅNAD FÖR MÅNAD','Plus = besparing med portfölj. Minus = merkostnad.',...monthly,`Vänliga hälsningar\n${seller}\nKraftringen`].join('\n\n');
 const e=escapeHtml,paragraph=t=>`<p style="font-size:14px;line-height:1.75;margin:0 0 14px;white-space:pre-wrap">${e(t)}</p>`,heading=t=>`<h2 style="font-size:17px;line-height:1.4;margin:28px 0 13px;color:#013c57">${e(t)}</h2>`;
 const cell='padding:12px 8px;border-bottom:1px solid #d9e3e8;text-align:right;font-size:13px;';
 const body=`<div class="customer-email" style="font-family:Arial,sans-serif;color:#013c57;background:#fff;max-width:720px;margin:auto"><div style="padding:24px;background:#013c57;color:#fff;border-radius:12px 12px 0 0"><p style="font-size:19px;font-weight:bold;margin:0 0 18px">Kraftringen <span style="font-size:12px;font-weight:normal;color:#c9dce6">/ Kundrummet</span></p><p style="font-size:12px;color:#fbc34e;letter-spacing:1px;margin:0 0 8px">ER ELJÄMFÖRELSE · ${e(r.periodLabel)}</p><h1 style="font-size:25px;line-height:1.3;margin:0;overflow-wrap:anywhere">${e(state.customer)}</h1></div><div style="padding:24px">${paragraph(greeting)}${paragraph(intro)}<p style="padding:12px;background:#edf3f6;font-size:13px;line-height:1.7;border-radius:6px">${e(coverage)}</p><table style="width:100%;border-collapse:collapse;margin:20px 0" aria-label="Beräknad jämförelse"><thead><tr><th style="${cell}text-align:left">Alternativ</th><th style="${cell}">öre/kWh</th><th style="${cell}">Kostnad, kr</th></tr></thead><tbody>${comparison.map(([name,rate,cost])=>`<tr><th scope="row" style="${cell}text-align:left;font-weight:normal">${e(name)}</th><td style="${cell}">${fmt(rate)}</td><td style="${cell}">${fmt(cost)}</td></tr>`).join('')}</tbody></table><div style="background:${same?'#edf3f6':extra?'#f8c3c6':'#fbc34e'};padding:20px;border-radius:8px"><strong style="font-size:14px">${e(resultTitle)}</strong><p style="font-size:26px;font-weight:bold;margin:10px 0 4px">${e(amount(r.difference))} kr</p><p style="font-size:14px;margin:0;line-height:1.6">${e(amount(r.differenceRate))} öre/kWh${same?'':extra?' högre än rörligt':' lägre än rörligt'}</p></div>${heading('För er verksamhet')}${impact.lines.map(paragraph).join('')}${heading('Så fungerar jämförelsen')}${explanation.map(paragraph).join('')}${notes?heading(sellerNotesTitle(seller))+`<div style="border-left:3px solid #fbc34e;padding-left:16px">${paragraph(notes)}</div>`:''}${followup.length?heading('Det här tar vi vidare')+followup.map(paragraph).join(''):''}${heading('Månad för månad')}${paragraph('Plus = besparing med portfölj. Minus = merkostnad.')}${r.rows.filter(row=>row.available).map(row=>`<div style="border-top:1px solid #d9e3e8;padding:14px 0"><strong style="font-size:14px">${e(row.month)} · ${fmt(row.volume,row.volume%1?2:0)} kWh</strong><p style="font-size:13px;line-height:1.8;margin:5px 0">Rörligt: ${fmt(row.variableRate)} öre/kWh · ${fmt(row.variable)} kr<br>Portfölj: ${fmt(row.portfolioRate)} öre/kWh · ${fmt(row.portfolio)} kr<br><strong>Skillnad: ${sign(row.differenceRate)} öre/kWh · ${sign(row.difference)} kr</strong></p></div>`).join('')}${paragraph(`Vänliga hälsningar\n${seller}\nKraftringen`)}</div></div>`;
 return {subject,text,body,html:`<!doctype html><html lang="sv"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${e(subject)}</title></head><body style="margin:0;background:#f2f5f7;padding:12px">${body}</body></html>`,recipientEmail,notesIncluded:!!notes};
}
function base64(text){const bytes=new TextEncoder().encode(text);let str='';for(const byte of bytes)str+=String.fromCharCode(byte);return btoa(str);}
function header(text){const chunks=[];let current='';for(const char of text){if(new TextEncoder().encode(current+char).length>42){chunks.push(current);current='';}current+=char;}if(current)chunks.push(current);return chunks.map(chunk=>'=?UTF-8?B?'+base64(chunk)+'?=').join('\r\n ');}
export function emailFile(email){
 if(!validEmail(email.recipientEmail))throw Error('Ange kundens mejladress.');
 const boundary='kundrum_customer_email_alternative';
 const part=(type,value)=>`--${boundary}\r\nContent-Type: ${type}; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n${base64(value).match(/.{1,76}/g).join('\r\n')}\r\n`;
 return `To: ${email.recipientEmail}\r\nSubject: ${header(email.subject)}\r\nMIME-Version: 1.0\r\nX-Unsent: 1\r\nContent-Type: multipart/alternative; boundary="${boundary}"\r\n\r\n${part('text/plain',email.text)}${part('text/html',email.html)}--${boundary}--\r\n`;
}
export function mailtoLink(email){if(!validEmail(email.recipientEmail))throw Error('Ange kundens mejladress.');return `mailto:${email.recipientEmail.split('@').map(encodeURIComponent).join('@')}?subject=${encodeURIComponent(email.subject)}&body=${encodeURIComponent(email.text)}`;}
