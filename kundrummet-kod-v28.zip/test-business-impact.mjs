import assert from 'node:assert/strict';
import {defaults,calculate,validateState} from './public/model.mjs';
import {businessImpact,validBusiness,BUSINESS_TYPES} from './public/business-impact.mjs';
import {buildCustomerEmail} from './public/customer-email.mjs';
const close=(a,b)=>assert.ok(Math.abs(a-b)<1e-8,`${a} != ${b}`);
const s=defaults();s.business={type:'brf',apartments:50};
let i=businessImpact(calculate(s),s);close(i.amount,220.6048);assert.equal(i.unit,'kr per lägenhet');assert.match(i.result,/220,60/);assert.match(i.sensitivity,/1.?860,00 kr/);assert.match(i.basis,/inte en beräknad ändring/);
const email=buildCustomerEmail(s);assert.match(email.text,/220,60 kr per lägenhet/);assert.match(email.body,/220,60 kr per lägenhet/);
s.period='2026';i=businessImpact(calculate(s),s);close(i.amount,745.4016);assert.match(i.scope,/9 av 12/);assert.match(i.sensitivity,/1.?260,00 kr/);assert.doesNotMatch(i.result,/per år|per månad/);
s.period='2025';s.portfolioFee=100;i=businessImpact(calculate(s),s);close(i.amount,-3424.9952);assert.equal(i.kind,'extra');assert.match(i.caption,/Högre/);
s.hedge=0;s.portfolioFee=s.variableFee;i=businessImpact(calculate(s),s);close(i.amount,0);assert.equal(i.kind,'equal');assert.match(i.percentText,/Samma/);
s.profiles['2025']=Array(12).fill(0);i=businessImpact(calculate(s),s);assert.equal(i.amount,null);assert.equal(i.kind,'empty');assert.equal(i.percent,null);
for(const apartments of [0,-1,1.5,100001,'50',NaN,Infinity])assert.equal(validBusiness({type:'brf',apartments}),false);
assert.equal(validBusiness({type:'__proto__',apartments:null}),false);assert.equal(validBusiness(null),false);
const old=defaults();delete old.business;assert.equal(validateState(old),true);assert.equal(businessImpact(calculate(old),old).business.type,'company');
const roundtrip=JSON.parse(JSON.stringify({...defaults(),business:{type:'brf',apartments:50}}));assert.equal(validateState(roundtrip),true);close(businessImpact(calculate(roundtrip),roundtrip).amount,220.6048);
for(const type of Object.keys(BUSINESS_TYPES)){const s=defaults(),before=calculate(s);s.business={type,apartments:type==='brf'?50:null};assert.equal(validateState(s),true);assert.deepEqual(calculate(s),before);}
console.log('PASS: per-apartment arithmetic, partial-year coverage without annualization, one-ore conversion, negative/equal/empty outcomes, email consistency, old state compatibility, JSON round-trip and unchanged pricing across sectors.');
