import { env } from 'cloudflare:workers';
import { handlePriceRecords } from '../../../lib/price-records.mjs';
export const dynamic = 'force-dynamic';
export function GET(request:Request){return handlePriceRecords(request,env.DB);}
export function POST(request:Request){return handlePriceRecords(request,env.DB);}
