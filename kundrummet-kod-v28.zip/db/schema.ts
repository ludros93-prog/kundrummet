import { sqliteTable, text, integer, index } from 'drizzle-orm/sqlite-core';

export const priceRecords = sqliteTable('price_records', {
  id: text('id').primaryKey(),
  provider: text('provider').notNull(),
  customer: text('customer').notNull(),
  area: text('area').notNull(),
  periodFrom: text('period_from').notNull(),
  periodTo: text('period_to').notNull(),
  sourceType: text('source_type').notNull(),
  payload: text('payload').notNull(),
  createdBy: text('created_by').notNull(),
  createdName: text('created_name').notNull(),
  createdAt: text('created_at').notNull(),
  supersedes: text('supersedes'),
}, table => [index('price_records_period').on(table.periodFrom,table.periodTo),index('price_records_created').on(table.createdAt)]);
