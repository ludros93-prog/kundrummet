import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {DatabaseSync} from 'node:sqlite';
import {JSDOM} from 'jsdom';
import {handlePriceRecords} from './lib/price-records.mjs';
const dom=new JSDOM(await readFile('public/index.html','utf8'),{url:'https://kundrum.test/'}),w=dom.window,errors=[];
Object.assign(globalThis,{window:w,document:w.document,localStorage:w.localStorage,confirm:()=>true});
Object.defineProperty(globalThis,'navigator',{value:{},configurable:true});
w.scrollTo=()=>{};w.HTMLElement.prototype.scrollIntoView=()=>{};
w.HTMLDialogElement.prototype.showModal=function(){this.open=true;};w.HTMLDialogElement.prototype.close=function(){this.open=false;};
w.addEventListener('error',e=>errors.push(e.error));
const sql=new DatabaseSync(':memory:');sql.exec(await readFile('drizzle/0000_sloppy_eternals.sql','utf8'));
const db={prepare(query){return {bind(...params){const statement=sql.prepare(query);return {first:async()=>statement.get(...params)||null,all:async()=>({results:statement.all(...params)}),run:async()=>statement.run(...params)};}};}};
let failSave=false,authorized=true;
globalThis.fetch=async(path,init={})=>{
 if(!path.startsWith('/api/'))return new Response(await readFile('public'+path));
 if(failSave&&init.method==='POST')throw Error('Test: nätverksavbrott');
 return handlePriceRecords(new Request('https://kundrum.test'+path,{...init,headers:{...init.headers,...authorized?{'oai-authenticated-user-id':'seller-1','oai-authenticated-user-email':'test@example.com'}:{}}}),db);
};
await import('./public/meeting-flow.mjs?customer-flow-test');
const el=id=>document.getElementById(id),state=()=>JSON.parse(localStorage.getItem('kundrum-meeting-v1'));
const click=selector=>document.querySelector(selector).dispatchEvent(new w.MouseEvent('click',{bubbles:true,cancelable:true}));
const input=(id,value)=>{const target=el(id);if(target.type==='checkbox')target.checked=value;else target.value=value;target.dispatchEvent(new w.Event('input',{bubbles:true}));target.dispatchEvent(new w.Event('change',{bubbles:true}));};
async function settled(){for(let i=0;i<30;i++)await new Promise(r=>setTimeout(r,1));}
input('customer','Testkund AB');input('annual','12000');input('shape','even');click('#applyAnnual');click('[data-step="2"]');click('[data-contract="fixed"]');click('[data-period="2026"]');input('manualPrice','80');click('[data-comparison="customer"]');
click('#showComparison');assert(!el('step2').hidden);assert(el('agreementError').textContent.includes('leverantör'));
for(const [id,value]of Object.entries({provider:'Fortum',type:'fixed',area:'SE4',sourceType:'contract',sourceRef:'Avtal 123',sourceDate:'2026-01-01',mode:'constant',rate:'100',monthlyFee:'50',scopeConfirmed:true,comparisonArea:'SE4',selectedMonthlyFee:'25',comparisonScopeChecked:true}))input('ca-'+id,value);
click('#showComparison');assert(!el('step3').hidden,el('agreementError').textContent);assert.match(el('result').textContent,/2\s700,00/);assert(el('result').textContent.includes('Fortum · Fastpris'));
click('[data-step="2"]');failSave=true;click('#ca-save');await settled();assert(el('ca-status').textContent.includes('nätverksavbrott'));assert.equal(state().customerAgreement.rate,100);assert(!el('ca-save').disabled);
failSave=false;click('#ca-save');await settled();assert(el('ca-status').textContent.includes('Sparat i teamets prisbank'),el('ca-status').textContent);const first=state().customerAgreementRecord.id;
input('ca-rate','110');click('#ca-save');await settled();const second=state().customerAgreementRecord.id;assert.notEqual(first,second);assert.equal(sql.prepare('SELECT supersedes FROM price_records WHERE id=?').get(second).supersedes,first);
click('#ca-bankOpen');await settled();assert.equal(document.querySelectorAll('.ca-record').length,2);input('ca-search','fortum');input('ca-year','2025');click('#ca-searchButton');await settled();assert.equal(document.querySelectorAll('.ca-record').length,0);input('ca-year','2026');click('#ca-searchButton');await settled();assert.equal(document.querySelectorAll('.ca-record').length,2);
click(`[data-record="${first}"]`);assert.equal(state().customerAgreement.rate,100);assert(!el('ca-bank').open);
// Opening another customer's saved record starts a clean meeting, never reuses their consumption.
input('ca-customer','Annan Testkund');click('#ca-save');await settled();const other=state().customerAgreementRecord.id;input('ca-customer','Testkund AB');click('#ca-bankOpen');await settled();click(`[data-record="${other}"]`);assert.equal(state().customer,'Annan Testkund');assert(state().profiles['2026'].every(x=>x===null));assert(!el('step1').hidden);
// Invoices deliberately replace estimated volumes only after explicit action.
input('annual','12000');click('#applyAnnual');click('[data-step="2"]');input('ca-mode','invoice');
const month=document.querySelector('[data-ca-month="2026-01"][data-part="kwh"]');month.value='1234';month.dispatchEvent(new w.Event('input',{bubbles:true}));click('#ca-applyVolumes');assert.equal(state().profiles['2026'][0],1234);assert.equal(state().profiles['2026'][1],null);assert.equal(state().sources['2026'],'own');assert.equal(state().consumptionMode,'separate');
authorized=false;click('#ca-bankOpen');await settled();assert(el('ca-bankStatus').textContent.includes('Logga in'));assert.equal(state().customerAgreement.months['2026-01'].kwh,1234);assert.deepEqual(errors,[]);
console.log('PASS: customer form, comparison guards, correct money, local draft, failed save/retry, shared versions and search, reload record, customer isolation, invoice volume replacement and signed-out state.');
