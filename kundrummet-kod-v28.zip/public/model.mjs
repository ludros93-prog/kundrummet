import {validBusiness} from './business-impact.mjs';
import {DATA} from './data.mjs';
export {DATA};
export const MONTHS=['Jan','Feb','Mar','Apr','Maj','Jun','Jul','Aug','Sep','Okt','Nov','Dec'];
export const hasMonthlyPrices=(prices,index)=>['hedged','spot','running','weighting'].every(key=>Number.isFinite(prices[key]?.[index]));
// Illustrative assumptions, not measured or official Kraftringen load profiles.
export const PROFILE_SHAPES=Object.freeze({
 winter:{label:'Vintertung',description:'65 % oktober–mars',weights:[12,12,11,8,6,4,4,5,8,9,10,11]},
 summer:{label:'Sommartung',description:'65 % april–september',weights:[4,5,8,9,10,11,12,12,11,8,6,4]},
 even:{label:'Jämn över året',description:'Lika mycket varje månad',weights:Array(12).fill(1)}
});
export function annualProfile(annualKwh,shape){
 if(!Number.isFinite(annualKwh)||annualKwh<.01||annualKwh>100000000||!Object.hasOwn(PROFILE_SHAPES,shape))throw Error('Ange en årsförbrukning mellan 0,01 och 100 000 000 kWh och välj en profil.');
 const total=Math.round(annualKwh*100),weights=PROFILE_SHAPES[shape].weights,sum=weights.reduce((a,v)=>a+v,0),raw=weights.map(w=>total*w/sum),cents=raw.map(Math.floor);
 // Largest remainder keeps the rounded months equal to the entered annual sum.
 const order=raw.map((v,i)=>({i,remainder:v-cents[i]})).sort((a,b)=>b.remainder-a.remainder||a.i-b.i);
 for(let i=0,left=total-cents.reduce((a,v)=>a+v,0);i<left;i++)cents[order[i].i]++;
 return cents.map(v=>v/100);
}
export function profileSourceLabel(s,period=s.period){
 if(s.sources[period]==='file')return 'Förbrukning från ditt Excelunderlag.';
 if(s.sources[period]==='estimated'){
  const e=s.estimates[period],shape=PROFILE_SHAPES[e.shape],annual=new Intl.NumberFormat('sv-SE',{maximumFractionDigits:2}).format(e.annualKwh);
  return `Uppskattad profil: ${shape.label.toLowerCase()}. Utgångspunkt: ${annual} kWh/år, ${shape.description.toLowerCase()}.${e.adjusted?' Månadsvärden har justerats manuellt efter fördelningen.':' Schablon, inte uppmätta månadsvärden.'}`;
 }
 return 'Din inlagda månadsförbrukning.';
}
export function defaults(){return {basis:DATA.id,customer:'Kund enligt ditt underlag',sellerName:'Ludwig Rosenberg',business:{type:'company',apartments:null},period:'2025',profiles:{'2025':[...DATA.periods['2025'].volume],'2026':[...DATA.periods['2026'].volume]},sources:{'2025':'file','2026':'file'},estimates:{},consumption:100,hedge:80,...DATA.parameters,notes:'',next:'',date:'',choice:'undecided'};}
export function calculate(state){
 const p=DATA.periods[state.period],h=state.hedge/100,profile=state.profiles[state.period];
 const rows=MONTHS.map((month,i)=>{
  const volume=profile[i]===null?null:profile[i]*state.consumption/100;
  if(!hasMonthlyPrices(p,i)||volume===null)return {month,index:i,available:false,volume};
  const cost=p.running[i]-p.weighting[i],hedgedPart=h*p.hedged[i],floatingPart=(1-h)*p.spot[i];
  const portfolioRate=hedgedPart+floatingPart+cost+state.portfolioFee,variableRate=p.spot[i]+cost+state.variableFee;
  const portfolio=volume*portfolioRate/100,variable=volume*variableRate/100;
  return {month,index:i,available:true,volume,hedged:p.hedged[i],spot:p.spot[i],running:p.running[i],weighting:p.weighting[i],cost,hedgedPart,floatingPart,portfolioRate,variableRate,fixedRate:state.fixed,portfolio,variable,fixed:volume*state.fixed/100,difference:variable-portfolio,differenceRate:variableRate-portfolioRate};
 });
 const available=rows.filter(r=>r.available),sum=k=>available.reduce((a,r)=>a+r[k],0),volume=sum('volume'),portfolio=sum('portfolio'),variable=sum('variable'),fixed=sum('fixed');
 return {rows,volume,portfolio,variable,fixed,difference:variable-portfolio,differenceRate:volume?(variable-portfolio)/volume*100:null,fixedDifference:fixed-portfolio,portfolioRate:volume?portfolio/volume*100:null,variableRate:volume?variable/volume*100:null,fixedRate:volume?fixed/volume*100:null,periodLabel:p.label,count:available.length};
}
export function parseProfile(text){
 const lines=text.replace(/^\uFEFF/,'').trim().split(/\r?\n/).filter(s=>s.trim()),values=Array(12).fill(null),used=new Set();let mode=null;
 for(let row=0;row<lines.length;row++){
  const line=lines[row];if(row===0&&/kwh|förbrukning|månad|month/i.test(line))continue;
  const cells=(line.includes(';')?line.split(';'):line.includes('\t')?line.split('\t'):line.split(',')).map(s=>s.trim().replace(/^"|"$/g,''));
  if(cells.length>2)throw Error('Använd månad och kWh, separerade med semikolon eller tabbar.');
  const current=cells.length===2?'named':'plain';if(mode&&mode!==current)throw Error('Alla rader behöver samma format.');mode=current;
  let index=used.size;
  if(mode==='named'){const key=cells[0].toLowerCase();index=MONTHS.findIndex(m=>m.toLowerCase()===key.slice(0,3));if(index<0&&/^\d{1,2}$/.test(key))index=Number(key)-1;}
  if(index<0||index>11||used.has(index))throw Error('Ange varje månad högst en gång, som Jan–Dec eller 1–12.');
  const str=cells.at(-1).replace(/\s/g,'').replace(',','.');const value=str===''?null:Number(str);
  if(value!==null&&(!Number.isFinite(value)||value<0||value>100000000))throw Error('Förbrukningen ska vara 0–100 000 000 kWh.');
  values[index]=value;used.add(index);
 }
 if(!values.some(v=>v>0))throw Error('Minst en månad behöver förbrukning över noll.');
 return values;
}
export function validateState(s){
 if(!validBusiness(s?.business))return false;
 if(s?.sellerName!==undefined&&(typeof s.sellerName!=='string'||!s.sellerName.trim()||s.sellerName.length>100||/[\r\n]/.test(s.sellerName)))return false;
 if(!s||s.basis!==DATA.id||!Object.hasOwn(DATA.periods,s.period)||typeof s.customer!=='string'||!s.customer.trim()||s.customer.length>120)return false;
 for(const period of Object.keys(DATA.periods)){
  const p=s.profiles?.[period];
  if(!Array.isArray(p)||p.length!==12||!p.every(v=>v===null||(Number.isFinite(v)&&v>=0&&v<=100000000))||!['file','own','estimated'].includes(s.sources?.[period]))return false;
  if(s.sources[period]==='estimated'){
   const e=s.estimates?.[period];
   if(!e||!Number.isFinite(e.annualKwh)||e.annualKwh<.01||e.annualKwh>100000000||!Object.hasOwn(PROFILE_SHAPES,e.shape)||typeof e.adjusted!=='boolean')return false;
   if(!e.adjusted&&!annualProfile(e.annualKwh,e.shape).every((v,i)=>p[i]!==null&&Math.abs(v-p[i])<1e-7))return false;
  }
 }
 for(const [k,min,max] of [['consumption',50,150],['hedge',0,100],['fixed',0,500],['portfolioFee',0,100],['variableFee',0,100]])if(!Number.isFinite(s[k])||s[k]<min||s[k]>max)return false;
 return typeof s.notes==='string'&&s.notes.length<=10000&&typeof s.next==='string'&&s.next.length<=1000&&['undecided','variable','portfolio','fixed'].includes(s.choice)&&typeof s.date==='string'&&(!s.date||/^\d{4}-\d{2}-\d{2}$/.test(s.date));
}
export function migrateLegacy(old){
 if(!old||typeof old.customer!=='string'||!Array.isArray(old.profile)||old.profile.length!==12||!old.profile.every(v=>Number.isFinite(v)&&v>=0&&v<=100000000))return null;
 const s=defaults();
 for(const k of ['customer','hedge','consumption','notes','next','date'])if(old[k]!==undefined)s[k]=old[k];
 s.profiles={'2025':[...old.profile],'2026':[...old.profile]};s.sources={'2025':'own','2026':'own'};
 s.choice=old.choice==='secured'?'portfolio':old.choice??'undecided';
 return validateState(s)?s:null;
}
