import assert from 'node:assert/strict';
import {buildPurchaseSchedule,purchaseSnapshot,dayClosure,holidayName} from './public/purchases.mjs';
const utc=s=>new Date(s+'T00:00:00.000Z');
const s=buildPurchaseSchedule(),byDate=iso=>s.days.find(d=>d.iso===iso);
assert.equal(s.start,'2026-01-01');assert.equal(s.finish,'2027-09-01');assert.equal(s.delivery,'2028-01-01');
assert.equal(s.days.length,731);assert.equal(s.marks[3].index,s.days.findIndex(d=>d.iso==='2027-09-01'));
// Independently enumerated holiday and closure dates for this example, not from the calendar implementation.
const closed=new Set(['2026-01-01','2026-01-06','2026-04-03','2026-04-06','2026-05-01','2026-05-14','2026-06-19','2026-12-24','2026-12-25','2026-12-31','2027-01-01','2027-01-06','2027-03-26','2027-03-29','2027-05-06','2027-06-25']);
let independentCount=0;
for(let t=Date.UTC(2026,0,1);t<Date.UTC(2027,8,1);t+=86400000){const d=new Date(t);if(d.getUTCDay()!==0&&d.getUTCDay()!==6&&!closed.has(d.toISOString().slice(0,10)))independentCount++;}
assert.equal(s.totalPurchases,independentCount);
for(const d of closed)assert.equal(byDate(d).buy,false,d);
for(const d of s.days){
 assert.ok(Math.abs(d.secured+d.market-100)<1e-10);
 assert.equal(d.secured,80*d.purchases/independentCount);
 if(d.buy){assert.ok(d.iso<'2027-09-01');assert.ok(![0,6].includes(d.date.getUTCDay()));assert.equal(d.added,80/independentCount);}
 else assert.equal(d.added,0);
 if(d.index>0&&!d.buy)assert.equal(d.secured,s.days[d.index-1].secured);
 if(d.iso>='2027-09-01'){assert.equal(d.secured,80);assert.equal(d.market,20);assert.equal(d.buy,false);}
}
assert.equal(byDate('2026-01-02').purchases,1);assert.equal(byDate('2026-01-03').purchases,1);assert.equal(byDate('2026-01-04').purchases,1);assert.equal(byDate('2026-01-05').purchases,2);assert.equal(byDate('2026-01-06').purchases,2);
assert.equal(byDate('2027-08-31').secured,80);assert.equal(byDate('2027-09-01').phase,'complete');assert.equal(byDate('2028-01-01').phase,'delivery');
assert.equal(holidayName(utc('2026-04-05')),'Påskdagen');assert.equal(holidayName(utc('2027-03-28')),'Påskdagen');assert.equal(holidayName(utc('2026-06-20')),'Midsommardagen');assert.equal(holidayName(utc('2027-11-06')),'Alla helgons dag');
assert.equal(dayClosure(utc('2026-05-15')),null); // no assumed bridge-day closure
assert.equal(holidayName(utc('2028-04-16')),'Påskdagen');
const leap=buildPurchaseSchedule(2030);assert.equal(leap.days.length,732);assert.ok(leap.days.some(d=>d.iso==='2028-02-29'));
for(const n of [-1,s.days.length,.5,NaN,'2',null])assert.throws(()=>purchaseSnapshot(n,s),RangeError);
for(const n of [2006,2101,2028.5,null])assert.throws(()=>buildPurchaseSchedule(n),RangeError);
console.log(`PASS: ${independentCount} independently counted daily purchases, public holidays/eves/weekends, leap year, stable 4-month tail, exact 80/20 endpoint and invalid inputs.`);
